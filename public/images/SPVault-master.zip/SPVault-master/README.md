# Auric Vault Portal

A modern web application for managing precious metals trading, consignments, and market news.

## Features

- 🔐 Secure Authentication System
- 💎 Product Management
- 📦 Consignment Tracking
- 📰 Blog System
- 📈 Market News Updates
- 📞 Contact Management
- 👥 User Role Management (Admin/User)

## Tech Stack

- **Frontend:**
  - React 18
  - TypeScript
  - Vite
  - Tailwind CSS
  - Shadcn UI Components
  - React Router
  - React Query
  - Axios

- **Backend:**
  - Node.js
  - Express
  - MongoDB
  - JWT Authentication

## Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- MongoDB

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/auric-vault-portal.git
   cd auric-vault-portal
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file in the root directory with the following variables:
   ```env
   VITE_API_URL=http://localhost:5000
   VITE_APP_NAME=Auric Vault Portal
   ```

4. Start the development server:
   ```bash
   npm run dev
   ```

## Project Structure

```
src/
├── components/         # React components
│   ├── auth/          # Authentication components
│   ├── products/      # Product-related components
│   ├── consignments/  # Consignment components
│   ├── blog/          # Blog components
│   ├── market-news/   # Market news components
│   └── contact/       # Contact form components
├── contexts/          # React contexts
├── lib/              # Utility functions and API
│   └── api/          # API service files
├── types/            # TypeScript type definitions
└── App.tsx           # Main application component
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint
- `npm run type-check` - Run TypeScript type checking

## API Endpoints

### Authentication
- POST `/auth/register` - Register new user
- POST `/auth/login` - User login
- POST `/auth/verify-email/:token` - Verify email
- POST `/auth/forgot-password` - Request password reset
- POST `/auth/reset-password` - Reset password

### Products
- GET `/products` - Get all products
- GET `/products/:id` - Get product details
- POST `/products/:id/reviews` - Add product review

### Consignments
- GET `/consignments` - Get user consignments
- POST `/consignments` - Create new consignment
- GET `/consignments/:id` - Get consignment details
- GET `/consignments/track/:trackingNumber` - Track consignment

### Blog
- GET `/blog` - Get all blog posts
- GET `/blog/:id` - Get blog post details
- POST `/blog` - Create new blog post (admin)
- PUT `/blog/:id` - Update blog post (admin)
- DELETE `/blog/:id` - Delete blog post (admin)

### Market News
- GET `/market-news` - Get all market news
- GET `/market-news/:id` - Get news details
- POST `/market-news` - Create news (admin)
- PUT `/market-news/:id` - Update news (admin)
- DELETE `/market-news/:id` - Delete news (admin)

### Contact
- POST `/contact` - Submit contact form

## Deployment

### Production Build
1. Create a production build:
   ```bash
   npm run build
   ```

2. The build files will be in the `dist` directory.

### Deployment Options

1. **Vercel**
   - Connect your GitHub repository
   - Configure environment variables
   - Deploy

2. **Netlify**
   - Connect your GitHub repository
   - Set build command: `npm run build`
   - Set publish directory: `dist`
   - Configure environment variables

3. **Traditional Hosting**
   - Upload the contents of the `dist` directory
   - Configure your web server (nginx, Apache)
   - Set up SSL certificates

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| VITE_API_URL | Backend API URL | http://localhost:5000 |
| VITE_APP_NAME | Application name | Auric Vault Portal |

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Security

- All API endpoints are protected with JWT authentication
- Passwords are hashed using bcrypt
- CORS is configured for security
- Input validation and sanitization
- Rate limiting on API endpoints

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support, email support@auricvault.com or create an issue in the repository.
