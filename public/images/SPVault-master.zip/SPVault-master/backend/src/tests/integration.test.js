import request from 'supertest';
import mongoose from 'mongoose';
import { app } from '../index.js';
import User from '../models/user.model.js';
import Product from '../models/product.model.js';
import Blog from '../models/blog.model.js';
import MarketNews from '../models/marketNews.model.js';
import Consignment from '../models/consignment.model.js';

let authToken;
let adminToken;
let testUserId;
let testProductId;
let testBlogId;
let testNewsId;
let testConsignmentId;

describe('Integration Tests', () => {
  describe('Authentication', () => {
    test('Register new user', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          firstName: 'Test',
          lastName: 'User',
          email: 'test@example.com',
          password: 'password123'
        });
      
      expect(res.status).toBe(201);
      expect(res.body.data.user).toHaveProperty('email', 'test@example.com');
      testUserId = res.body.data.user._id;
    });

    test('Login user', async () => {
      const res = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'test@example.com',
          password: 'password123'
        });
      
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('token');
      authToken = res.body.token;
    });
  });

  describe('Products', () => {
    test('Create product (admin only)', async () => {
      const res = await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          name: 'Test Product',
          description: 'Test Description',
          category: 'gold',
          type: 'bullion',
          weight: { value: 100, unit: 'g' },
          purity: 99.9,
          price: { current: 5000, currency: 'USD' },
          stock: 10
        });
      
      expect(res.status).toBe(201);
      expect(res.body.data.product).toHaveProperty('name', 'Test Product');
      testProductId = res.body.data.product._id;
    });

    test('Get all products', async () => {
      const res = await request(app)
        .get('/api/products');
      
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body.data.products)).toBe(true);
    });

    test('Get product by ID', async () => {
      const res = await request(app)
        .get(`/api/products/${testProductId}`);
      
      expect(res.status).toBe(200);
      expect(res.body.data.product._id).toBe(testProductId);
    });
  });

  describe('Blogs', () => {
    test('Create blog post', async () => {
      const res = await request(app)
        .post('/api/blog')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Test Blog',
          content: 'Test Content',
          summary: 'Test Summary',
          category: 'market-news',
          tags: ['test', 'blog']
        });
      
      expect(res.status).toBe(201);
      expect(res.body.data.blog).toHaveProperty('title', 'Test Blog');
      testBlogId = res.body.data.blog._id;
    });

    test('Get all blogs', async () => {
      const res = await request(app)
        .get('/api/blog');
      
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body.data.blogs)).toBe(true);
    });
  });

  describe('Market News', () => {
    test('Create market news', async () => {
      const res = await request(app)
        .post('/api/market-news')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Test News',
          content: 'Test Content',
          summary: 'Test Summary',
          category: 'gold',
          source: { name: 'Test Source' }
        });
      
      expect(res.status).toBe(201);
      expect(res.body.data.news).toHaveProperty('title', 'Test News');
      testNewsId = res.body.data.news._id;
    });

    test('Get all market news', async () => {
      const res = await request(app)
        .get('/api/market-news');
      
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body.data.news)).toBe(true);
    });
  });

  describe('Consignments', () => {
    test('Create consignment', async () => {
      const res = await request(app)
        .post('/api/consignments')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          type: 'purchase',
          items: [{
            product: testProductId,
            quantity: 1,
            price: 5000
          }],
          shippingAddress: {
            street: '123 Test St',
            city: 'Test City',
            state: 'Test State',
            country: 'Test Country',
            zipCode: '12345'
          },
          payment: {
            method: 'credit_card',
            amount: 5000,
            currency: 'USD'
          }
        });
      
      expect(res.status).toBe(201);
      expect(res.body.data.consignment).toHaveProperty('type', 'purchase');
      testConsignmentId = res.body.data.consignment._id;
    });

    test('Get user consignments', async () => {
      const res = await request(app)
        .get('/api/consignments/my-consignments')
        .set('Authorization', `Bearer ${authToken}`);
      
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body.data.consignments)).toBe(true);
    });
  });

  describe('Comments and Likes', () => {
    test('Add comment to blog', async () => {
      const res = await request(app)
        .post(`/api/blog/${testBlogId}/comments`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          content: 'Test Comment'
        });
      
      expect(res.status).toBe(201);
      expect(res.body.data.comment).toHaveProperty('content', 'Test Comment');
    });

    test('Like blog post', async () => {
      const res = await request(app)
        .patch(`/api/blog/${testBlogId}/like`)
        .set('Authorization', `Bearer ${authToken}`);
      
      expect(res.status).toBe(200);
      expect(res.body.data.likes).toContain(testUserId);
    });
  });

  describe('Statistics', () => {
    test('Get product statistics', async () => {
      const res = await request(app)
        .get('/api/products/stats');
      
      expect(res.status).toBe(200);
      expect(res.body.data.stats).toBeDefined();
    });

    test('Get blog statistics', async () => {
      const res = await request(app)
        .get('/api/blog/stats');
      
      expect(res.status).toBe(200);
      expect(res.body.data.stats).toBeDefined();
    });

    test('Get market news statistics', async () => {
      const res = await request(app)
        .get('/api/market-news/stats');
      
      expect(res.status).toBe(200);
      expect(res.body.data.stats).toBeDefined();
    });
  });
}); 