import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Product description is required']
  },
  category: {
    type: String,
    required: [true, 'Product category is required'],
    enum: ['gold', 'silver', 'platinum', 'palladium', 'other']
  },
  type: {
    type: String,
    required: [true, 'Product type is required'],
    enum: ['bullion', 'coin', 'bar', 'jewelry', 'other']
  },
  weight: {
    value: {
      type: Number,
      required: [true, 'Product weight is required']
    },
    unit: {
      type: String,
      enum: ['g', 'kg', 'oz', 'troy oz'],
      default: 'g'
    }
  },
  purity: {
    type: Number,
    required: [true, 'Product purity is required'],
    min: 0,
    max: 100
  },
  price: {
    current: {
      type: Number,
      required: [true, 'Current price is required']
    },
    previous: Number,
    currency: {
      type: String,
      default: 'USD'
    }
  },
  stock: {
    type: Number,
    required: [true, 'Stock quantity is required'],
    min: 0
  },
  images: [{
    url: String,
    alt: String
  }],
  specifications: {
    dimensions: {
      length: Number,
      width: Number,
      height: Number,
      unit: {
        type: String,
        enum: ['mm', 'cm', 'inch'],
        default: 'mm'
      }
    },
    manufacturer: String,
    year: Number,
    serialNumber: String
  },
  features: [String],
  ratings: {
    average: {
      type: Number,
      default: 0,
      min: 0,
      max: 5
    },
    count: {
      type: Number,
      default: 0
    }
  },
  reviews: [{
    user: {
      type: mongoose.Schema.ObjectId,
      ref: 'User',
      required: true
    },
    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5
    },
    comment: String,
    createdAt: {
      type: Date,
      default: Date.now
    }
  }],
  status: {
    type: String,
    enum: ['active', 'inactive', 'out-of-stock'],
    default: 'active'
  },
  tags: [String],
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Index for better search performance
productSchema.index({ name: 'text', description: 'text', tags: 'text' });

// Virtual for product URL
productSchema.virtual('url').get(function() {
  return `/products/${this._id}`;
});

// Update average rating when a review is added
productSchema.methods.updateAverageRating = async function() {
  const stats = await this.constructor.aggregate([
    {
      $match: { _id: this._id }
    },
    {
      $unwind: '$reviews'
    },
    {
      $group: {
        _id: '$_id',
        averageRating: { $avg: '$reviews.rating' },
        numReviews: { $sum: 1 }
      }
    }
  ]);

  if (stats.length > 0) {
    this.ratings.average = stats[0].averageRating;
    this.ratings.count = stats[0].numReviews;
  } else {
    this.ratings.average = 0;
    this.ratings.count = 0;
  }

  await this.save();
};

const Product = mongoose.model('Product', productSchema);

export default Product; 