import mongoose from 'mongoose';

const marketNewsSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'News title is required'],
    trim: true
  },
  content: {
    type: String,
    required: [true, 'News content is required']
  },
  summary: {
    type: String,
    required: [true, 'News summary is required']
  },
  category: {
    type: String,
    required: [true, 'News category is required'],
    enum: [
      'gold',
      'silver',
      'platinum',
      'palladium',
      'crypto',
      'forex',
      'stocks',
      'economy'
    ]
  },
  source: {
    name: {
      type: String,
      required: [true, 'Source name is required']
    },
    url: String
  },
  author: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: [true, 'News must have an author']
  },
  tags: [String],
  images: [{
    url: String,
    alt: String
  }],
  status: {
    type: String,
    enum: ['draft', 'published', 'archived'],
    default: 'draft'
  },
  publishedAt: Date,
  marketImpact: {
    type: String,
    enum: ['positive', 'negative', 'neutral'],
    default: 'neutral'
  },
  relatedAssets: [{
    type: {
      type: String,
      enum: ['gold', 'silver', 'platinum', 'palladium', 'crypto', 'forex', 'stock'],
      required: true
    },
    symbol: String,
    name: String
  }],
  priceData: {
    before: Number,
    after: Number,
    change: Number,
    changePercentage: Number,
    currency: {
      type: String,
      default: 'USD'
    }
  },
  views: {
    type: Number,
    default: 0
  },
  likes: [{
    type: mongoose.Schema.ObjectId,
    ref: 'User'
  }],
  comments: [{
    user: {
      type: mongoose.Schema.ObjectId,
      ref: 'User',
      required: true
    },
    content: {
      type: String,
      required: true
    },
    createdAt: {
      type: Date,
      default: Date.now
    },
    updatedAt: {
      type: Date,
      default: Date.now
    }
  }],
  seo: {
    metaTitle: String,
    metaDescription: String,
    keywords: [String]
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for comment count
marketNewsSchema.virtual('commentCount').get(function() {
  return this.comments.length;
});

// Virtual for like count
marketNewsSchema.virtual('likeCount').get(function() {
  return this.likes.length;
});

// Index for better search performance
marketNewsSchema.index({ title: 'text', content: 'text', tags: 'text' });

const MarketNews = mongoose.model('MarketNews', marketNewsSchema);

export default MarketNews; 