import mongoose from 'mongoose';

const consignmentSchema = new mongoose.Schema({
  trackingNumber: {
    type: String,
    required: true,
    unique: true
  },
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: [true, 'Consignment must belong to a user']
  },
  type: {
    type: String,
    required: [true, 'Consignment type is required'],
    enum: ['purchase', 'sale', 'storage', 'transfer']
  },
  status: {
    type: String,
    required: true,
    enum: [
      'pending',
      'processing',
      'in-transit',
      'delivered',
      'cancelled',
      'failed'
    ],
    default: 'pending'
  },
  items: [{
    product: {
      type: mongoose.Schema.ObjectId,
      ref: 'Product',
      required: true
    },
    quantity: {
      type: Number,
      required: true,
      min: 1
    },
    price: {
      type: Number,
      required: true
    }
  }],
  totalValue: {
    type: Number,
    required: true
  },
  shippingAddress: {
    street: {
      type: String,
      required: true
    },
    city: {
      type: String,
      required: true
    },
    state: {
      type: String,
      required: true
    },
    country: {
      type: String,
      required: true
    },
    zipCode: {
      type: String,
      required: true
    }
  },
  payment: {
    method: {
      type: String,
      required: true,
      enum: ['credit_card', 'bank_transfer', 'crypto', 'cash']
    },
    status: {
      type: String,
      required: true,
      enum: ['pending', 'completed', 'failed', 'refunded'],
      default: 'pending'
    },
    transactionId: String,
    amount: {
      type: Number,
      required: true
    },
    currency: {
      type: String,
      default: 'USD'
    }
  },
  tracking: [{
    status: {
      type: String,
      required: true
    },
    location: String,
    description: String,
    timestamp: {
      type: Date,
      default: Date.now
    }
  }],
  insurance: {
    isInsured: {
      type: Boolean,
      default: false
    },
    provider: String,
    policyNumber: String,
    coverage: Number
  },
  notes: String,
  estimatedDelivery: Date,
  actualDelivery: Date,
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Generate tracking number before saving
consignmentSchema.pre('save', async function(next) {
  if (this.isNew) {
    const date = new Date();
    const year = date.getFullYear().toString().slice(-2);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    this.trackingNumber = `AV${year}${month}${random}`;
  }
  next();
});

// Add tracking update method
consignmentSchema.methods.addTrackingUpdate = async function(status, location, description) {
  this.tracking.push({
    status,
    location,
    description,
    timestamp: Date.now()
  });

  this.status = status;
  if (status === 'delivered') {
    this.actualDelivery = Date.now();
  }

  await this.save();
};

// Calculate total value
consignmentSchema.methods.calculateTotalValue = async function() {
  let total = 0;
  for (const item of this.items) {
    total += item.price * item.quantity;
  }
  this.totalValue = total;
  await this.save();
};

const Consignment = mongoose.model('Consignment', consignmentSchema);

export default Consignment; 