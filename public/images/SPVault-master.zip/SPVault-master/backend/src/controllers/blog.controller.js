import Blog from '../models/blog.model.js';
import { AppError } from '../utils/appError.js';
import { catchAsync } from '../utils/catchAsync.js';

// Get all blogs with filtering, sorting, and pagination
export const getAllBlogs = catchAsync(async (req, res, next) => {
  const queryObj = { ...req.query };
  const excludedFields = ['page', 'sort', 'limit', 'fields', 'search'];
  excludedFields.forEach(el => delete queryObj[el]);

  // Only show published blogs for non-admin users
  if (req.user?.role !== 'admin') {
    queryObj.status = 'published';
  }

  let query = Blog.find(queryObj)
    .populate({
      path: 'author',
      select: 'firstName lastName'
    });

  // Search functionality
  if (req.query.search) {
    query = query.find({
      $text: { $search: req.query.search }
    });
  }

  // Sorting
  if (req.query.sort) {
    const sortBy = req.query.sort.split(',').join(' ');
    query = query.sort(sortBy);
  } else {
    query = query.sort('-publishedAt');
  }

  // Field limiting
  if (req.query.fields) {
    const fields = req.query.fields.split(',').join(' ');
    query = query.select(fields);
  } else {
    query = query.select('-__v');
  }

  // Pagination
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 10;
  const skip = (page - 1) * limit;

  query = query.skip(skip).limit(limit);

  const blogs = await query;
  const total = await Blog.countDocuments(queryObj);

  res.status(200).json({
    status: 'success',
    results: blogs.length,
    total,
    totalPages: Math.ceil(total / limit),
    currentPage: page,
    data: {
      blogs
    }
  });
});

// Get single blog
export const getBlog = catchAsync(async (req, res, next) => {
  const blog = await Blog.findOne({ slug: req.params.slug })
    .populate({
      path: 'author',
      select: 'firstName lastName'
    })
    .populate({
      path: 'comments.user',
      select: 'firstName lastName'
    });

  if (!blog) {
    return next(new AppError('No blog found with that slug', 404));
  }

  // Increment views
  blog.views += 1;
  await blog.save({ validateBeforeSave: false });

  res.status(200).json({
    status: 'success',
    data: {
      blog
    }
  });
});

// Create new blog
export const createBlog = catchAsync(async (req, res, next) => {
  req.body.author = req.user.id;
  
  if (req.body.status === 'published') {
    req.body.publishedAt = Date.now();
  }

  const blog = await Blog.create(req.body);

  res.status(201).json({
    status: 'success',
    data: {
      blog
    }
  });
});

// Update blog
export const updateBlog = catchAsync(async (req, res, next) => {
  const blog = await Blog.findById(req.params.id);

  if (!blog) {
    return next(new AppError('No blog found with that ID', 404));
  }

  // Check if user is the author or admin
  if (blog.author.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError('You are not authorized to update this blog', 403));
  }

  // Set publishedAt if status is changing to published
  if (req.body.status === 'published' && blog.status !== 'published') {
    req.body.publishedAt = Date.now();
  }

  Object.assign(blog, req.body);
  await blog.save();

  res.status(200).json({
    status: 'success',
    data: {
      blog
    }
  });
});

// Delete blog
export const deleteBlog = catchAsync(async (req, res, next) => {
  const blog = await Blog.findById(req.params.id);

  if (!blog) {
    return next(new AppError('No blog found with that ID', 404));
  }

  // Check if user is the author or admin
  if (blog.author.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError('You are not authorized to delete this blog', 403));
  }

  await blog.deleteOne();

  res.status(204).json({
    status: 'success',
    data: null
  });
});

// Add comment to blog
export const addComment = catchAsync(async (req, res, next) => {
  const { content } = req.body;
  const blog = await Blog.findById(req.params.id);

  if (!blog) {
    return next(new AppError('No blog found with that ID', 404));
  }

  const comment = {
    user: req.user.id,
    content
  };

  blog.comments.push(comment);
  await blog.save();

  res.status(201).json({
    status: 'success',
    data: {
      comment
    }
  });
});

// Like/Unlike blog
export const toggleLike = catchAsync(async (req, res, next) => {
  const blog = await Blog.findById(req.params.id);

  if (!blog) {
    return next(new AppError('No blog found with that ID', 404));
  }

  const likeIndex = blog.likes.indexOf(req.user.id);

  if (likeIndex === -1) {
    // Like the blog
    blog.likes.push(req.user.id);
  } else {
    // Unlike the blog
    blog.likes.splice(likeIndex, 1);
  }

  await blog.save();

  res.status(200).json({
    status: 'success',
    data: {
      likes: blog.likes
    }
  });
});

// Get blog statistics
export const getBlogStats = catchAsync(async (req, res, next) => {
  const stats = await Blog.aggregate([
    {
      $group: {
        _id: '$category',
        numBlogs: { $sum: 1 },
        totalViews: { $sum: '$views' },
        avgViews: { $avg: '$views' },
        totalLikes: { $sum: { $size: '$likes' } },
        totalComments: { $sum: { $size: '$comments' } }
      }
    },
    {
      $sort: { numBlogs: -1 }
    }
  ]);

  res.status(200).json({
    status: 'success',
    data: {
      stats
    }
  });
}); 