import Consignment from '../models/consignment.model.js';
import { AppError } from '../utils/appError.js';
import { catchAsync } from '../utils/catchAsync.js';

// Get all consignments (with filtering)
export const getAllConsignments = catchAsync(async (req, res, next) => {
  const queryObj = { ...req.query };
  const excludedFields = ['page', 'sort', 'limit', 'fields'];
  excludedFields.forEach(el => delete queryObj[el]);

  let query = Consignment.find(queryObj)
    .populate({
      path: 'user',
      select: 'firstName lastName email'
    })
    .populate({
      path: 'items.product',
      select: 'name category type weight'
    });

  // Sorting
  if (req.query.sort) {
    const sortBy = req.query.sort.split(',').join(' ');
    query = query.sort(sortBy);
  } else {
    query = query.sort('-createdAt');
  }

  // Pagination
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 10;
  const skip = (page - 1) * limit;

  query = query.skip(skip).limit(limit);

  const consignments = await query;
  const total = await Consignment.countDocuments(queryObj);

  res.status(200).json({
    status: 'success',
    results: consignments.length,
    total,
    totalPages: Math.ceil(total / limit),
    currentPage: page,
    data: {
      consignments
    }
  });
});

// Get single consignment
export const getConsignment = catchAsync(async (req, res, next) => {
  const consignment = await Consignment.findById(req.params.id)
    .populate({
      path: 'user',
      select: 'firstName lastName email'
    })
    .populate({
      path: 'items.product',
      select: 'name category type weight'
    });

  if (!consignment) {
    return next(new AppError('No consignment found with that ID', 404));
  }

  res.status(200).json({
    status: 'success',
    data: {
      consignment
    }
  });
});

// Create new consignment
export const createConsignment = catchAsync(async (req, res, next) => {
  // Add user to request body
  req.body.user = req.user.id;

  const consignment = await Consignment.create(req.body);
  await consignment.calculateTotalValue();

  res.status(201).json({
    status: 'success',
    data: {
      consignment
    }
  });
});

// Update consignment
export const updateConsignment = catchAsync(async (req, res, next) => {
  const consignment = await Consignment.findById(req.params.id);

  if (!consignment) {
    return next(new AppError('No consignment found with that ID', 404));
  }

  // Check if user is the owner or admin
  if (consignment.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError('You are not authorized to update this consignment', 403));
  }

  Object.assign(consignment, req.body);
  await consignment.calculateTotalValue();
  await consignment.save();

  res.status(200).json({
    status: 'success',
    data: {
      consignment
    }
  });
});

// Add tracking update
export const addTrackingUpdate = catchAsync(async (req, res, next) => {
  const { status, location, description } = req.body;
  const consignment = await Consignment.findById(req.params.id);

  if (!consignment) {
    return next(new AppError('No consignment found with that ID', 404));
  }

  // Only admin can update tracking
  if (req.user.role !== 'admin') {
    return next(new AppError('You are not authorized to update tracking', 403));
  }

  await consignment.addTrackingUpdate(status, location, description);

  res.status(200).json({
    status: 'success',
    data: {
      consignment
    }
  });
});

// Get consignment by tracking number
export const getConsignmentByTrackingNumber = catchAsync(async (req, res, next) => {
  const consignment = await Consignment.findOne({ trackingNumber: req.params.trackingNumber })
    .populate({
      path: 'user',
      select: 'firstName lastName email'
    })
    .populate({
      path: 'items.product',
      select: 'name category type weight'
    });

  if (!consignment) {
    return next(new AppError('No consignment found with that tracking number', 404));
  }

  res.status(200).json({
    status: 'success',
    data: {
      consignment
    }
  });
});

// Get user's consignments
export const getMyConsignments = catchAsync(async (req, res, next) => {
  const consignments = await Consignment.find({ user: req.user.id })
    .populate({
      path: 'items.product',
      select: 'name category type weight'
    });

  res.status(200).json({
    status: 'success',
    results: consignments.length,
    data: {
      consignments
    }
  });
});

// Cancel consignment
export const cancelConsignment = catchAsync(async (req, res, next) => {
  const consignment = await Consignment.findById(req.params.id);

  if (!consignment) {
    return next(new AppError('No consignment found with that ID', 404));
  }

  // Check if user is the owner or admin
  if (consignment.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError('You are not authorized to cancel this consignment', 403));
  }

  // Check if consignment can be cancelled
  if (['delivered', 'cancelled', 'failed'].includes(consignment.status)) {
    return next(new AppError('This consignment cannot be cancelled', 400));
  }

  consignment.status = 'cancelled';
  await consignment.addTrackingUpdate('cancelled', 'N/A', 'Consignment cancelled by user');
  await consignment.save();

  res.status(200).json({
    status: 'success',
    data: {
      consignment
    }
  });
}); 