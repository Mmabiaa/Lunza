import MarketNews from '../models/marketNews.model.js';
import { AppError } from '../utils/appError.js';
import { catchAsync } from '../utils/catchAsync.js';

// Get all market news with filtering, sorting, and pagination
export const getAllMarketNews = catchAsync(async (req, res, next) => {
  const queryObj = { ...req.query };
  const excludedFields = ['page', 'sort', 'limit', 'fields', 'search'];
  excludedFields.forEach(el => delete queryObj[el]);

  // Only show published news for non-admin users
  if (req.user?.role !== 'admin') {
    queryObj.status = 'published';
  }

  let query = MarketNews.find(queryObj)
    .populate({
      path: 'author',
      select: 'firstName lastName'
    });

  // Search functionality
  if (req.query.search) {
    query = query.find({
      $text: { $search: req.query.search }
    });
  }

  // Sorting
  if (req.query.sort) {
    const sortBy = req.query.sort.split(',').join(' ');
    query = query.sort(sortBy);
  } else {
    query = query.sort('-publishedAt');
  }

  // Field limiting
  if (req.query.fields) {
    const fields = req.query.fields.split(',').join(' ');
    query = query.select(fields);
  } else {
    query = query.select('-__v');
  }

  // Pagination
  const page = parseInt(req.query.page, 10) || 1;
  const limit = parseInt(req.query.limit, 10) || 10;
  const skip = (page - 1) * limit;

  query = query.skip(skip).limit(limit);

  const news = await query;
  const total = await MarketNews.countDocuments(queryObj);

  res.status(200).json({
    status: 'success',
    results: news.length,
    total,
    totalPages: Math.ceil(total / limit),
    currentPage: page,
    data: {
      news
    }
  });
});

// Get single market news
export const getMarketNews = catchAsync(async (req, res, next) => {
  const news = await MarketNews.findById(req.params.id)
    .populate({
      path: 'author',
      select: 'firstName lastName'
    })
    .populate({
      path: 'comments.user',
      select: 'firstName lastName'
    });

  if (!news) {
    return next(new AppError('No news found with that ID', 404));
  }

  // Increment views
  news.views += 1;
  await news.save({ validateBeforeSave: false });

  res.status(200).json({
    status: 'success',
    data: {
      news
    }
  });
});

// Create new market news
export const createMarketNews = catchAsync(async (req, res, next) => {
  req.body.author = req.user.id;
  
  if (req.body.status === 'published') {
    req.body.publishedAt = Date.now();
  }

  const news = await MarketNews.create(req.body);

  res.status(201).json({
    status: 'success',
    data: {
      news
    }
  });
});

// Update market news
export const updateMarketNews = catchAsync(async (req, res, next) => {
  const news = await MarketNews.findById(req.params.id);

  if (!news) {
    return next(new AppError('No news found with that ID', 404));
  }

  // Check if user is the author or admin
  if (news.author.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError('You are not authorized to update this news', 403));
  }

  // Set publishedAt if status is changing to published
  if (req.body.status === 'published' && news.status !== 'published') {
    req.body.publishedAt = Date.now();
  }

  Object.assign(news, req.body);
  await news.save();

  res.status(200).json({
    status: 'success',
    data: {
      news
    }
  });
});

// Delete market news
export const deleteMarketNews = catchAsync(async (req, res, next) => {
  const news = await MarketNews.findById(req.params.id);

  if (!news) {
    return next(new AppError('No news found with that ID', 404));
  }

  // Check if user is the author or admin
  if (news.author.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(new AppError('You are not authorized to delete this news', 403));
  }

  await news.deleteOne();

  res.status(204).json({
    status: 'success',
    data: null
  });
});

// Add comment to market news
export const addComment = catchAsync(async (req, res, next) => {
  const { content } = req.body;
  const news = await MarketNews.findById(req.params.id);

  if (!news) {
    return next(new AppError('No news found with that ID', 404));
  }

  const comment = {
    user: req.user.id,
    content
  };

  news.comments.push(comment);
  await news.save();

  res.status(201).json({
    status: 'success',
    data: {
      comment
    }
  });
});

// Like/Unlike market news
export const toggleLike = catchAsync(async (req, res, next) => {
  const news = await MarketNews.findById(req.params.id);

  if (!news) {
    return next(new AppError('No news found with that ID', 404));
  }

  const likeIndex = news.likes.indexOf(req.user.id);

  if (likeIndex === -1) {
    // Like the news
    news.likes.push(req.user.id);
  } else {
    // Unlike the news
    news.likes.splice(likeIndex, 1);
  }

  await news.save();

  res.status(200).json({
    status: 'success',
    data: {
      likes: news.likes
    }
  });
});

// Get market news statistics
export const getMarketNewsStats = catchAsync(async (req, res, next) => {
  const stats = await MarketNews.aggregate([
    {
      $group: {
        _id: '$category',
        numNews: { $sum: 1 },
        totalViews: { $sum: '$views' },
        avgViews: { $avg: '$views' },
        totalLikes: { $sum: { $size: '$likes' } },
        totalComments: { $sum: { $size: '$comments' } },
        marketImpact: {
          $push: '$marketImpact'
        }
      }
    },
    {
      $sort: { numNews: -1 }
    }
  ]);

  res.status(200).json({
    status: 'success',
    data: {
      stats
    }
  });
}); 