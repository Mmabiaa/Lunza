import express from 'express';
import { catchAsync } from '../utils/catchAsync.js';
import { AppError } from '../utils/appError.js';
import { sendEmail } from '../utils/email.js';

const router = express.Router();

// Submit contact form
router.post('/', catchAsync(async (req, res, next) => {
  const { name, email, subject, message } = req.body;

  // Validate required fields
  if (!name || !email || !message) {
    return next(new AppError('Please provide name, email and message', 400));
  }

  // Send email to admin
  const emailMessage = `
    New Contact Form Submission:
    
    Name: ${name}
    Email: ${email}
    Subject: ${subject || 'No subject provided'}
    
    Message:
    ${message}
  `;

  try {
    await sendEmail({
      email: process.env.ADMIN_EMAIL,
      subject: `Contact Form: ${subject || 'New Message'}`,
      message: emailMessage
    });

    // Send confirmation email to user
    await sendEmail({
      email,
      subject: 'Thank you for contacting Auric Vault',
      message: `
        Dear ${name},
        
        Thank you for contacting Auric Vault. We have received your message and will get back to you shortly.
        
        Best regards,
        Auric Vault Team
      `
    });

    res.status(200).json({
      status: 'success',
      message: 'Your message has been sent successfully'
    });
  } catch (err) {
    return next(new AppError('Error sending email. Please try again later.', 500));
  }
}));

export default router; 