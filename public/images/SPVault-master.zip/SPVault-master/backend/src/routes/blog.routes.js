import express from 'express';
import {
  getAllBlogs,
  getBlog,
  createBlog,
  updateBlog,
  deleteBlog,
  addComment,
  toggleLike,
  getBlogStats
} from '../controllers/blog.controller.js';
import { protect, restrictTo } from '../controllers/auth.controller.js';

const router = express.Router();

// Public routes
router.get('/', getAllBlogs);
router.get('/stats', getBlogStats);
router.get('/:slug', getBlog);

// Protected routes
router.use(protect);

// Comment and like routes
router.post('/:id/comments', addComment);
router.patch('/:id/like', toggleLike);

// Author and admin routes
router.post('/', createBlog);
router.patch('/:id', updateBlog);
router.delete('/:id', deleteBlog);

export default router; 