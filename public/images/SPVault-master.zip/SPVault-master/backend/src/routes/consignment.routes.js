import express from 'express';
import {
  getAllConsignments,
  getConsignment,
  createConsignment,
  updateConsignment,
  addTrackingUpdate,
  getConsignmentByTrackingNumber,
  getMyConsignments,
  cancelConsignment
} from '../controllers/consignment.controller.js';
import { protect, restrictTo } from '../controllers/auth.controller.js';

const router = express.Router();

// Public routes
router.get('/track/:trackingNumber', getConsignmentByTrackingNumber);

// Protected routes
router.use(protect);

// User routes
router.get('/my-consignments', getMyConsignments);
router.post('/', createConsignment);
router.patch('/:id', updateConsignment);
router.patch('/:id/cancel', cancelConsignment);

// Admin routes
router.use(restrictTo('admin'));
router.get('/', getAllConsignments);
router.get('/:id', getConsignment);
router.patch('/:id/tracking', addTrackingUpdate);

export default router; 