import express from 'express';
import User from '../models/user.model.js';

const router = express.Router();

// Get all users
router.get('/', async (req, res) => {
  const users = await User.find().select('-password');
  res.json({ status: 'success', data: { users } });
});

// Get user by ID
router.get('/:id', async (req, res) => {
  const user = await User.findById(req.params.id).select('-password');
  if (!user) {
    return res.status(404).json({ status: 'fail', message: 'User not found' });
  }
  res.json({ status: 'success', data: { user } });
});

export default router; 