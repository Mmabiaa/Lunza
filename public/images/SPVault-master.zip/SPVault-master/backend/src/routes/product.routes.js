import express from 'express';
import {
  getAllProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
  addReview,
  getProductStats
} from '../controllers/product.controller.js';
import { protect, restrictTo } from '../controllers/auth.controller.js';

const router = express.Router();

// Public routes
router.get('/', getAllProducts);
router.get('/stats', getProductStats);
router.get('/:id', getProduct);

// Protected routes
router.use(protect);

// Review routes
router.post('/:id/reviews', addReview);

// Admin only routes
router.use(restrictTo('admin'));
router.post('/', createProduct);
router.patch('/:id', updateProduct);
router.delete('/:id', deleteProduct);

export default router; 