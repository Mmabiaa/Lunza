import express from 'express';
import {
  getAllMarketNews,
  getMarketNews,
  createMarketNews,
  updateMarketNews,
  deleteMarketNews,
  addComment,
  toggleLike,
  getMarketNewsStats
} from '../controllers/marketNews.controller.js';
import { protect, restrictTo } from '../controllers/auth.controller.js';

const router = express.Router();

// Public routes
router.get('/', getAllMarketNews);
router.get('/stats', getMarketNewsStats);
router.get('/:id', getMarketNews);

// Protected routes
router.use(protect);

router.post('/:id/comments', addComment);
router.patch('/:id/like', toggleLike);

// Author and admin routes
router.post('/', restrictTo('author', 'admin'), createMarketNews);
router.patch('/:id', restrictTo('author', 'admin'), updateMarketNews);
router.delete('/:id', restrictTo('author', 'admin'), deleteMarketNews);

export default router; 