import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { Search } from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQsPage = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const faqCategories = [
    {
      category: "General Questions",
      questions: [
        {
          question: "Why should I invest in gold?",
          answer: "Gold has been a store of value for thousands of years. It offers portfolio diversification, inflation protection, and security during times of economic uncertainty. Unlike paper assets, physical gold cannot be printed or diluted, making it a reliable long-term investment."
        },
        {
          question: "How do I start investing in gold?",
          answer: "Starting your gold investment journey is simple with SP VAULT. First, educate yourself about different gold products (coins, bars, ETFs) through our Investment Guides. Then, determine your investment goals and budget. Finally, make your first purchase through our secure platform or schedule a consultation with our advisors for personalized guidance."
        },
        {
          question: "What is the minimum amount I need to start investing in gold?",
          answer: "At SP VAULT, you can start investing in gold with as little as $100 for fractional gold products. For physical gold coins, investments typically start around $500. We offer options for every budget, allowing you to build your gold portfolio gradually over time."
        },
      ]
    },
    {
      category: "Physical Gold",
      questions: [
        {
          question: "What are the advantages of owning physical gold?",
          answer: "Physical gold offers complete ownership without counterparty risk, privacy in wealth storage, protection against systemic financial crises, and tangible security you can hold. It also provides inheritance benefits and can be easily liquidated worldwide."
        },
        {
          question: "How do I store physical gold securely?",
          answer: "SP VAULT offers several secure storage solutions: our high-security vaults with full insurance, safe deposit boxes at partner banks, or secure home storage options with our guidance. We recommend professional storage for larger investments to ensure maximum security and insurance coverage."
        },
        {
          question: "How is the purity of gold measured?",
          answer: "Gold purity is measured in karats (for jewelry) or fineness (for investment gold). Pure gold is 24 karats or 999.9 fine (99.99% pure). Investment-grade gold typically ranges from 999 to 9999 fine. All SP VAULT products come with certificates of authenticity verifying their exact purity and weight."
        },
      ]
    },
    {
      category: "Gold IRAs",
      questions: [
        {
          question: "What is a Gold IRA?",
          answer: "A Gold IRA is a self-directed Individual Retirement Account that holds physical precious metals instead of paper assets. It offers the same tax advantages as traditional IRAs while providing the security and inflation protection of physical gold."
        },
        {
          question: "What types of gold can I hold in a Gold IRA?",
          answer: "IRS regulations specify that Gold IRA investments must be in IRS-approved coins and bars with a minimum fineness of 99.5% (except for American Gold Eagles). Approved products include American Gold Eagles, Canadian Maple Leafs, Australian Kangaroos, and certain gold bars produced by accredited refiners."
        },
        {
          question: "How do I transfer my existing IRA to a Gold IRA?",
          answer: "SP VAULT simplifies the process with our Gold IRA specialists. We handle the paperwork for direct transfers from your existing IRA custodian to a self-directed IRA custodian that allows precious metals. This process typically takes 10-15 business days and can be done without tax penalties when executed properly."
        },
      ]
    },
    {
      category: "Market and Pricing",
      questions: [
        {
          question: "How is the price of gold determined?",
          answer: "Gold prices are primarily determined by trading on global exchanges like the London Bullion Market, COMEX, and Shanghai Gold Exchange. Factors influencing prices include supply and demand dynamics, central bank activities, currency values (especially the US dollar), inflation rates, interest rates, and geopolitical events."
        },
        {
          question: "Why do gold prices fluctuate?",
          answer: "Gold prices fluctuate due to multiple factors: changes in supply and demand, currency value fluctuations (particularly the US dollar), central bank policies, interest rate changes, inflation expectations, geopolitical tensions, and market sentiment toward risk. Short-term volatility is common, but gold has maintained its value over long periods."
        },
        {
          question: "What is the difference between the spot price and premium?",
          answer: "The spot price is the current market price for immediate delivery of raw gold. The premium is the additional cost over the spot price that you pay when purchasing physical gold products. Premiums cover minting, distribution, dealer margins, and the intrinsic value of the specific product. Premiums vary by product type, size, rarity, and market conditions."
        },
      ]
    },
  ];

  const filteredFaqs = searchTerm
    ? faqCategories.map(category => ({
        ...category,
        questions: category.questions.filter(faq => 
          faq.question.toLowerCase().includes(searchTerm.toLowerCase()) || 
          faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
        )
      })).filter(category => category.questions.length > 0)
    : faqCategories;

  return (
    <div className="min-h-screen bg-navy text-white">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gold mb-4">Frequently Asked Questions</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto mb-8">
            Find answers to common questions about gold investment, products, and services.
          </p>
          
          <div className="max-w-xl mx-auto relative">
            <input
              type="text"
              placeholder="Search for questions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-navy-light border border-gold/30 rounded-full px-6 py-3 pr-12 focus:outline-none focus:border-gold text-white"
            />
            <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gold/70 h-5 w-5" />
          </div>
        </div>
        
        {filteredFaqs.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-gray-400 text-lg">No questions found matching your search. Please try different keywords.</p>
          </div>
        ) : (
          <div className="space-y-10">
            {filteredFaqs.map((category, categoryIndex) => (
              <div key={categoryIndex}>
                <h2 className="text-2xl font-bold text-gold mb-6">{category.category}</h2>
                <Accordion type="single" collapsible className="space-y-4">
                  {category.questions.map((faq, faqIndex) => (
                    <AccordionItem key={faqIndex} value={`item-${categoryIndex}-${faqIndex}`} className="glass-card border-gold/20">
                      <AccordionTrigger className="text-left px-6 py-4 text-lg font-medium text-white hover:text-gold">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="px-6 pb-4 text-gray-300">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default FAQsPage;
