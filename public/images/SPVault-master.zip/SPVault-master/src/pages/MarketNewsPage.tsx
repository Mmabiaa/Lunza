import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { FileText } from 'lucide-react';

const MarketNewsPage = () => {
  const featuredNews = {
    title: "Gold Prices Surge as Global Economic Uncertainty Rises",
    description: "Gold has reached a six-month high amid growing concerns about inflation and geopolitical tensions, attracting investors seeking safe-haven assets.",
    date: "May 18, 2025",
    readTime: "8 min",
    author: "Sarah Johnson",
    category: "Market Analysis",
    imageUrl: "https://i.pinimg.com/736x/20/31/3c/20313ca6492e9b2df38b93911d7e23fb.jpg"
  };

  const newsList = [
    {
      title: "Central Banks Increase Gold Reserves Amid Currency Volatility",
      description: "Major central banks have accelerated their gold purchases in Q1 2025, signaling a strategic shift toward hard assets.",
      date: "May 15, 2025",
      readTime: "6 min",
      author: "Robert Chen",
      category: "Central Banks",
      imageUrl: "https://i.pinimg.com/736x/27/04/ad/2704ad7ae65acda9708ca6e8c6731703.jpg"
    },
    {
      title: "New Mining Technologies Could Increase Gold Production by 15%",
      description: "Breakthrough extraction methods promise to make previously unprofitable gold deposits economically viable, industry experts report.",
      date: "May 12, 2025",
      readTime: "7 min",
      author: "Michael Torres",
      category: "Mining Industry",
      imageUrl: "https://i.pinimg.com/736x/2f/c5/7b/2fc57be0b8f040057648e888b90ed8ed.jpg"
    },
    {
      title: "Gold ETF Inflows Reach Record Levels in April",
      description: "Investors poured over $8.5 billion into gold ETFs last month, the highest monthly inflow since records began in 2004.",
      date: "May 10, 2025",
      readTime: "5 min",
      author: "Emily Richards",
      category: "Investment Trends",
      imageUrl: "https://images.unsplash.com/photo-1640340434855-6084b1f4901c?auto=format&fit=crop&q=80&w=2064"
    },
    {
      title: "Gold-Backed Cryptocurrencies Gain Popularity Among Digital Investors",
      description: "The convergence of traditional gold investment and blockchain technology is creating new opportunities for diversification.",
      date: "May 8, 2025",
      readTime: "9 min",
      author: "David Wong",
      category: "Digital Assets",
      imageUrl: "https://i.pinimg.com/736x/45/9b/2d/459b2d1a632227921bbe0499e2b9fdb8.jpg"
    },
    {
      title: "India's Gold Demand Expected to Rise 20% in 2025",
      description: "Favorable monsoon season and economic growth are driving increased consumer gold purchases in the world's second-largest gold market.",
      date: "May 5, 2025",
      readTime: "6 min",
      author: "Priya Sharma",
      category: "Regional Markets",
      imageUrl: "https://i.pinimg.com/736x/8e/e6/a1/8ee6a1578dff466b01ae529df34b9197.jpg"
    },
    {
      title: "Analysis: How Inflation Fears Are Reshaping Gold Investment Strategies",
      description: "As inflation concerns persist, investment advisors are recommending new approaches to incorporating gold in portfolios.",
      date: "May 2, 2025",
      readTime: "10 min",
      author: "Thomas Miller",
      category: "Market Analysis",
      imageUrl: "https://i.pinimg.com/736x/a0/be/17/a0be170c452cc5330e7061487da22715.jpg?auto=format&fit=crop&q=80&w=2070"
    }
  ];

  const categoryColors = {
    "Market Analysis": "bg-purple-500/20 text-purple-400",
    "Central Banks": "bg-blue-500/20 text-blue-400",
    "Mining Industry": "bg-green-500/20 text-green-400",
    "Investment Trends": "bg-yellow-500/20 text-yellow-400",
    "Digital Assets": "bg-red-500/20 text-red-400",
    "Regional Markets": "bg-indigo-500/20 text-indigo-400"
  };

  return (
    <div className="min-h-screen bg-navy text-white">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gold mb-4">Market News</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Stay informed with the latest developments in the gold market, industry trends, and expert analyses.
          </p>
        </div>
        
        {/* Featured News */}
        <div className="glass-card overflow-hidden mb-16">
          <div className="md:flex">
            <div className="md:w-1/2">
              <img 
                src={featuredNews.imageUrl} 
                alt={featuredNews.title} 
                className="w-full h-full object-cover" 
              />
            </div>
            <div className="md:w-1/2 p-8 flex flex-col justify-center">
              <div className="flex items-center gap-3 mb-4">
                <span className="bg-gold/20 text-gold px-3 py-1 rounded-full text-xs font-medium">
                  Featured
                </span>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${categoryColors[featuredNews.category as keyof typeof categoryColors]}`}>
                  {featuredNews.category}
                </span>
              </div>
              <h2 className="text-3xl font-bold text-gold mb-3">{featuredNews.title}</h2>
              <p className="text-gray-300 mb-4">{featuredNews.description}</p>
              <div className="flex justify-between items-center text-sm text-gray-400 mb-6">
                <span>{featuredNews.date}</span>
                <span className="flex items-center"><FileText className="h-3 w-3 mr-1" /> {featuredNews.readTime}</span>
                <span>By {featuredNews.author}</span>
              </div>
              <button className="btn-gold self-start">
                Read Full Article
              </button>
            </div>
          </div>
        </div>
        
        {/* News List */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {newsList.map((news, index) => (
            <div key={index} className="glass-card overflow-hidden hover:shadow-lg hover:shadow-gold/10 transition-all duration-300">
              <div className="h-48 overflow-hidden">
                <img 
                  src={news.imageUrl} 
                  alt={news.title} 
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" 
                />
              </div>
              <div className="p-6">
                <div className="flex justify-between items-center mb-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${categoryColors[news.category as keyof typeof categoryColors]}`}>
                    {news.category}
                  </span>
                  <span className="text-gray-400 text-sm">{news.date}</span>
                </div>
                <h3 className="text-xl font-bold text-gold mb-2">{news.title}</h3>
                <p className="text-gray-400 mb-4">{news.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-400">By {news.author}</span>
                  <span className="text-gray-400 text-sm flex items-center">
                    <FileText className="h-3 w-3 mr-1" /> {news.readTime}
                  </span>
                </div>
                <button className="text-gold hover:text-gold-light transition-colors flex items-center text-sm font-medium mt-4">
                  Read Article <span className="ml-2">→</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default MarketNewsPage;
