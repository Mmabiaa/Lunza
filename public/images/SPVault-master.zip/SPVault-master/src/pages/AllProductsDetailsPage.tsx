import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

interface Product {
  id: string;
  category: string;
  title: string;
  description: string;
  price: number;
  purity: string;
  weight: string;
  imageUrl: string;
  features: string[];
  specifications?: {
    dimensions?: string;
    manufacturer?: string;
    certification?: string;
    storage?: string;
  };
}

const products: Product[] = [
  {
    id: '1',
    category: 'Gold',
    title: 'Gold Investment Bar',
    description: 'Our flagship 999.9 fine gold bar, perfect for long-term investment.',
    price: 1950.00,
    purity: '99.99%',
    weight: '1 oz',
    imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&q=80&w=2070',
    features: ['LBMA Certified', 'Secure Storage Available', 'Instant Liquidity'],
    specifications: {
      dimensions: '45mm x 25mm x 2mm',
      manufacturer: 'SP VAULT Mint',
      certification: 'LBMA Good Delivery',
      storage: 'Allocated Storage Available'
    }
  },
  {
    id: '2',
    category: 'Gold',
    title: 'Gold Sovereign Coin',
    description: 'Historic gold coins with excellent liquidity and worldwide recognition.',
    price: 520.00,
    purity: '22 Karat',
    weight: '7.98g',
    imageUrl: 'https://images.unsplash.com/photo-1605792657660-596af9009e82?auto=format&fit=crop&q=80&w=2071',
    features: ['Government Minted', 'Historic Value', 'Worldwide Recognition'],
    specifications: {
      dimensions: '22mm diameter',
      manufacturer: 'Royal Mint',
      certification: 'Government Guaranteed',
      storage: 'Allocated Storage Available'
    }
  },
  {
    id: '3',
    category: 'Gold',
    title: 'Premium Gold Bullion',
    description: 'High-purity gold bullion bars with tamper-evident packaging.',
    price: 9750.00,
    purity: '99.99%',
    weight: '5 oz',
    imageUrl: 'https://i.pinimg.com/736x/96/7a/3f/967a3fb9863cb0560db2e52156645a9c.jpg',
    features: ['Tamper-Evident Packaging', 'Secure Storage Available', 'High Purity'],
    specifications: {
      dimensions: '89mm x 45mm x 8mm',
      manufacturer: 'SP VAULT Mint',
      certification: 'LBMA Good Delivery',
      storage: 'Allocated Storage Available'
    }
  },
  {
    id: '4',
    category: 'Gold',
    title: 'Gold Maple Leaf',
    description: 'Canadian gold maple leaf coin with exceptional purity.',
    price: 2049.99,
    purity: '99.99%',
    weight: '1 oz',
    imageUrl: 'https://i.pinimg.com/736x/f9/5c/75/f95c75eb86bf4207031ef61a17473821.jpg',
    features: ['Royal Canadian Mint', 'Highest Purity', 'Security Features'],
    specifications: {
      dimensions: '30mm diameter',
      manufacturer: 'Royal Canadian Mint',
      certification: 'Government Guaranteed',
      storage: 'Allocated Storage Available'
    }
  },
  {
    id: '5',
    category: 'Gold',
    title: 'Gold Eagle Coin',
    description: 'American gold eagle coin, the official gold bullion coin of the United States.',
    price: 2099.99,
    purity: '91.67%',
    weight: '1 oz',
    imageUrl: 'https://i.pinimg.com/736x/39/24/c9/3924c9a8efcd129132a143602b92b28e.jpg',
    features: ['US Mint', 'Legal Tender', 'Iconic Design'],
    specifications: {
      dimensions: '32.7mm diameter',
      manufacturer: 'US Mint',
      certification: 'Government Guaranteed',
      storage: 'Allocated Storage Available'
    }
  },
  {
    id: '6',
    category: 'Gold',
    title: 'Gold Philharmonic',
    description: 'Austrian gold philharmonic coin featuring classical music theme.',
    price: 2029.99,
    purity: '99.99%',
    weight: '1 oz',
    imageUrl: 'https://i.pinimg.com/736x/06/44/43/0644437b5f41a2f42ccc382e46b34893.jpg',
    features: ['Austrian Mint', 'Pure Gold', 'Cultural Design'],
    specifications: {
      dimensions: '37mm diameter',
      manufacturer: 'Austrian Mint',
      certification: 'Government Guaranteed',
      storage: 'Allocated Storage Available'
    }
  },
  {
    id: '7',
    category: 'Gold',
    title: 'Gold Krugerrand',
    description: 'South African gold krugerrand, the world\'s first modern gold bullion coin.',
    price: 1979.99,
    purity: '91.67%',
    weight: '1 oz',
    imageUrl: 'https://i.pinimg.com/736x/8c/27/01/8c27012d3adaf362b42311cae7aac5b3.jpg',
    features: ['South African Mint', 'Historical', 'Widely Recognized'],
    specifications: {
      dimensions: '32.6mm diameter',
      manufacturer: 'South African Mint',
      certification: 'Government Guaranteed',
      storage: 'Allocated Storage Available'
    }
  },
  {
    id: '8',
    category: 'Gold',
    title: 'Gold Britannia',
    description: 'British gold britannia coin with advanced security features.',
    price: 2039.99,
    purity: '99.99%',
    weight: '1 oz',
    imageUrl: 'https://i.pinimg.com/736x/c9/97/f0/c997f07265fd12f04d5f58d55c83117c.jpg',
    features: ['Royal Mint', 'Security Features', 'Tax Efficient'],
    specifications: {
      dimensions: '32.69mm diameter',
      manufacturer: 'Royal Mint',
      certification: 'Government Guaranteed',
      storage: 'Allocated Storage Available'
    }
  },
  {
    id: '9',
    category: 'Gold',
    title: 'Gold Kangaroo',
    description: 'Australian gold kangaroo coin with unique annual designs.',
    price: 2019.99,
    purity: '99.99%',
    weight: '1 oz',
    imageUrl: 'https://i.pinimg.com/736x/96/0d/fe/960dfe333db94c0f2b713dc6482ae44b.jpg',
    features: ['Perth Mint', 'Annual Design', 'High Purity'],
    specifications: {
      dimensions: '32.1mm diameter',
      manufacturer: 'Perth Mint',
      certification: 'Government Guaranteed',
      storage: 'Allocated Storage Available'
    }
  },
  {
    id: '10',
    category: 'Gold',
    title: 'Gold Panda',
    description: 'Chinese gold panda coin with changing panda designs.',
    price: 2049.99,
    purity: '99.9%',
    weight: '1 oz',
    imageUrl: 'https://i.pinimg.com/736x/69/99/25/6999256df77aff4d9b0e0274a18625c5.jpg',
    features: ['Chinese Mint', 'Annual Design', 'Collectible'],
    specifications: {
      dimensions: '30mm diameter',
      manufacturer: 'Chinese Mint',
      certification: 'Government Guaranteed',
      storage: 'Allocated Storage Available'
    }
  },
  {
    id: '11',
    category: 'Gold',
    title: 'Gold Card Bar',
    description: 'American gold buffalo coin with 24-karat purity.',
    price: 2099.99,
    purity: '99.99%',
    weight: '1 oz',
    imageUrl: 'https://i.pinimg.com/736x/20/31/3c/20313ca6492e9b2df38b93911d7e23fb.jpg',
    features: ['US Mint', 'Pure Gold', 'Native American Design'],
    specifications: {
      dimensions: '32.7mm diameter',
      manufacturer: 'US Mint',
      certification: 'Government Guaranteed',
      storage: 'Allocated Storage Available'
    }
  }
];

const AllProductsDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = products.find(p => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen bg-navy-dark text-white">
        <Navbar />
        <div className="flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="text-center">
            <h1 className="text-2xl font-playfair font-bold text-gold mb-4">Product Not Found</h1>
            <button
              onClick={() => navigate('/all-products')}
              className="bg-gold text-navy-dark font-bold py-2 px-4 rounded-md hover:bg-gold/90 transition-colors duration-300"
            >
              Back to Products
            </button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-dark text-white">
      <Navbar />
      {/* Hero Section */}
      <div className="relative h-[40vh] bg-navy-light flex items-center justify-center">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-navy-dark"></div>
        <div className="relative z-10 text-center">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-gold mb-4">{product.title}</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">{product.description}</p>
        </div>
      </div>

      {/* Product Details Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Image */}
          <div className="bg-navy-light rounded-lg overflow-hidden border border-gold/20">
            <div className="relative h-[500px] w-full">
              <img
                src={product.imageUrl}
                alt={product.title}
                className="absolute inset-0 w-full h-full object-contain p-4"
              />
            </div>
          </div>

          {/* Product Information */}
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-playfair font-bold text-gold mb-4">Product Information</h2>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-400">Category:</span>
                  <span className="text-white">{product.category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Weight:</span>
                  <span className="text-white">{product.weight}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Purity:</span>
                  <span className="text-white">{product.purity}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Price:</span>
                  <span className="text-gold font-bold">${product.price.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Features */}
            <div>
              <h2 className="text-2xl font-playfair font-bold text-gold mb-4">Features</h2>
              <ul className="space-y-2">
                {product.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-gray-300">
                    <svg className="w-5 h-5 text-gold mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            {/* Specifications */}
            {product.specifications && (
              <div>
                <h2 className="text-2xl font-playfair font-bold text-gold mb-4">Specifications</h2>
                <div className="space-y-4">
                  {product.specifications.dimensions && (
                    <div className="flex justify-between">
                      <span className="text-gray-400">Dimensions:</span>
                      <span className="text-white">{product.specifications.dimensions}</span>
                    </div>
                  )}
                  {product.specifications.manufacturer && (
                    <div className="flex justify-between">
                      <span className="text-gray-400">Manufacturer:</span>
                      <span className="text-white">{product.specifications.manufacturer}</span>
                    </div>
                  )}
                  {product.specifications.certification && (
                    <div className="flex justify-between">
                      <span className="text-gray-400">Certification:</span>
                      <span className="text-white">{product.specifications.certification}</span>
                    </div>
                  )}
                  {product.specifications.storage && (
                    <div className="flex justify-between">
                      <span className="text-gray-400">Storage:</span>
                      <span className="text-white">{product.specifications.storage}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-4">
              <button className="flex-1 bg-gold text-navy-dark font-bold py-3 px-6 rounded-md hover:bg-gold/90 transition-colors duration-300">
                Add to Cart
              </button>
              <button 
                onClick={() => navigate('/contact')}
                className="flex-1 bg-navy-light text-gold border border-gold font-bold py-3 px-6 rounded-md hover:bg-navy-light/90 transition-colors duration-300"
              >
                Contact Sales
              </button>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default AllProductsDetailsPage; 