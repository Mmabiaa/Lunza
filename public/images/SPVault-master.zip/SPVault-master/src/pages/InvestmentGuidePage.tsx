
import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { ChevronLeft, FileText, Clock } from 'lucide-react';
import { investmentGuides } from '../data/investmentGuides';

const InvestmentGuidePage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  // Find the investment guide based on the ID parameter
  const guide = investmentGuides.find(guide => guide.id === id);
  
  useEffect(() => {
    // If guide not found, redirect to the investment guides page
    if (!guide) {
      navigate('/investment-guides');
    }
    
    // Scroll to top when guide loads
    window.scrollTo(0, 0);
  }, [guide, navigate]);
  
  // Return null while redirecting
  if (!guide) return null;

  // Helper function to get level color
  const getLevelColor = (level: string) => {
    switch (level) {
      case "Beginner":
        return "bg-green-500/20 text-green-400";
      case "Intermediate":
        return "bg-blue-500/20 text-blue-400";
      case "Advanced":
        return "bg-purple-500/20 text-purple-400";
      default:
        return "bg-gray-500/20 text-gray-400";
    }
  };
  
  return (
    <div className="min-h-screen bg-navy text-white">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <button 
          onClick={() => navigate('/investment-guides')}
          className="flex items-center text-gray-400 hover:text-gold transition-colors mb-8"
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Back to Investment Guides
        </button>
        
        <div className="glass-card overflow-hidden">
          <div className="h-80 overflow-hidden">
            <img 
              src={guide.imageUrl} 
              alt={guide.title} 
              className="w-full h-full object-cover" 
            />
          </div>
          
          <div className="p-8">
            <div className="flex items-center gap-3 mb-4">
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getLevelColor(guide.level)}`}>
                {guide.level}
              </span>
              <span className="flex items-center text-gray-400 text-sm">
                <Clock className="h-3 w-3 mr-1" /> {guide.readTime}
              </span>
            </div>
            
            <h1 className="text-3xl md:text-4xl font-bold text-gold mb-6">{guide.title}</h1>
            
            <div className="prose prose-invert prose-gold max-w-none">
              {guide.content.map((paragraph, index) => (
                <React.Fragment key={index}>
                  {paragraph.type === 'paragraph' && <p>{paragraph.text}</p>}
                  {paragraph.type === 'heading' && <h2 className="text-xl font-bold text-gold mt-8 mb-4">{paragraph.text}</h2>}
                  {paragraph.type === 'list' && (
                    <ul className="list-disc pl-6 my-4">
                      {paragraph.items.map((item, itemIndex) => (
                        <li key={itemIndex} className="mb-2">{item}</li>
                      ))}
                    </ul>
                  )}
                  {paragraph.type === 'quote' && (
                    <blockquote className="border-l-4 border-gold pl-4 italic my-6">
                      {paragraph.text}
                    </blockquote>
                  )}
                  {paragraph.type === 'image' && (
                    <div className="my-8">
                      <img 
                        src={paragraph.url} 
                        alt={paragraph.caption || ''} 
                        className="w-full rounded-lg" 
                      />
                      {paragraph.caption && (
                        <p className="text-center text-sm text-gray-400 mt-2">{paragraph.caption}</p>
                      )}
                    </div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
        
        <div className="mt-12">
          <h3 className="text-xl font-bold text-gold mb-6">Related Guides</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {investmentGuides
              .filter(relatedGuide => relatedGuide.id !== id)
              .slice(0, 3)
              .map((relatedGuide, index) => (
                <div key={index} className="glass-card overflow-hidden hover:shadow-lg hover:shadow-gold/10 transition-all duration-300">
                  <div className="h-40 overflow-hidden">
                    <img 
                      src={relatedGuide.imageUrl} 
                      alt={relatedGuide.title} 
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" 
                    />
                  </div>
                  <div className="p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getLevelColor(relatedGuide.level)}`}>
                        {relatedGuide.level}
                      </span>
                      <span className="text-gray-400 text-xs">{relatedGuide.readTime}</span>
                    </div>
                    <h4 className="text-lg font-bold text-gold mb-2 line-clamp-2">{relatedGuide.title}</h4>
                    <button 
                      onClick={() => navigate(`/investment-guides/${relatedGuide.id}`)}
                      className="text-gold hover:text-gold-light transition-colors flex items-center text-sm font-medium"
                    >
                      Read Guide <span className="ml-2">→</span>
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default InvestmentGuidePage;
