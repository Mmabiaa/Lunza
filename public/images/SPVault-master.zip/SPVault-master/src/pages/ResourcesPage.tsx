import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { FileText, ChartBar } from 'lucide-react';

const ResourcesPage = () => {
  const resources = [
    {
      id: "1",
      title: "Gold Investment Guide",
      description: "A comprehensive guide to investing in gold, covering everything from physical gold to ETFs.",
      category: "Investment",
      imageUrl: "https://i.pinimg.com/736x/0c/32/54/0c3254e4e3ccd350aef61a934cc5f763.jpg"
    },
    {
      id: "2",
      title: "Market Analysis Reports",
      description: "Detailed analysis of gold market trends and future predictions.",
      category: "Analysis",
      imageUrl: "https://i.pinimg.com/736x/64/67/0d/64670deef4d02f99791f8178530e0b40.jpg"
    },
    {
      id: "3",
      title: "Trading Strategies",
      description: "Expert strategies for trading gold in different market conditions.",
      category: "Trading",
      imageUrl: "https://i.pinimg.com/736x/20/31/3c/20313ca6492e9b2df38b93911d7e23fb.jpg"
    },
    {
      title: "Gold Price Charts",
      description: "Access real-time and historical gold price data with interactive charts and analysis tools.",
      icon: <ChartBar className="h-10 w-10 text-gold" />,
      path: "/gold-price-charts"
    },
    {
      title: "Investment Guides",
      description: "Comprehensive guides to help you make informed decisions about gold investments.",
      icon: <FileText className="h-10 w-10 text-gold" />,
      path: "/investment-guides"
    },
    {
      title: "Market News",
      description: "Stay updated with the latest gold market news, trends, and expert analyses.",
      icon: <FileText className="h-10 w-10 text-gold" />,
      path: "/market-news"
    },
    {
      title: "FAQs",
      description: "Find answers to commonly asked questions about gold investment, storage, and trading.",
      icon: <FileText className="h-10 w-10 text-gold" />,
      path: "/faqs"
    },
    {
      title: "Blog",
      description: "Explore our collection of articles, insights, and guides on gold investment strategies.",
      icon: <FileText className="h-10 w-10 text-gold" />,
      path: "/blog"
    }
  ];

  return (
    <div className="min-h-screen bg-navy text-white">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gold mb-4">Resources</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Access our comprehensive collection of resources to enhance your gold investment knowledge and strategy.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {resources.map((resource, index) => (
            <a 
              href={resource.path} 
              key={index}
              className="glass-card hover:border-gold hover:shadow-lg hover:shadow-gold/10 transition-all duration-300"
            >
              <div className="flex flex-col items-center text-center p-6">
                <div className="mb-4">
                  {resource.icon}
                </div>
                <h3 className="text-xl font-bold text-gold mb-2">{resource.title}</h3>
                <p className="text-gray-400">{resource.description}</p>
              </div>
            </a>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default ResourcesPage;
