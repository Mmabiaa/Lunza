
import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { ChevronLeft, FileText, User, Clock, Calendar } from 'lucide-react';
import { blogPosts } from '../data/blogPosts';

const BlogPostPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  // Find the blog post based on the ID parameter
  const post = blogPosts.find(post => post.id === id);
  
  useEffect(() => {
    // If post not found, redirect to the blog page
    if (!post) {
      navigate('/blog');
    }
    
    // Scroll to top when post loads
    window.scrollTo(0, 0);
  }, [post, navigate]);
  
  // Return null while redirecting
  if (!post) return null;
  
  return (
    <div className="min-h-screen bg-navy text-white">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <button 
          onClick={() => navigate('/blog')}
          className="flex items-center text-gray-400 hover:text-gold transition-colors mb-8"
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Back to Blog
        </button>
        
        <div className="glass-card overflow-hidden">
          <div className="h-80 overflow-hidden">
            <img 
              src={post.imageUrl} 
              alt={post.title} 
              className="w-full h-full object-cover" 
            />
          </div>
          
          <div className="p-8">
            <div className="flex flex-wrap gap-3 mb-4">
              <span className="bg-navy-light px-3 py-1 rounded-full text-xs font-medium text-gray-300">
                {post.category}
              </span>
              <span className="bg-gold/20 text-gold px-3 py-1 rounded-full text-xs font-medium">
                Featured
              </span>
            </div>
            
            <h1 className="text-3xl md:text-4xl font-bold text-gold mb-6">{post.title}</h1>
            
            <div className="flex flex-wrap justify-between items-center text-sm text-gray-400 mb-8 gap-4">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-navy-light rounded-full flex items-center justify-center mr-3">
                  <User className="h-5 w-5 text-gold/70" />
                </div>
                <div>
                  <p className="font-medium text-white">{post.author}</p>
                  <p className="text-xs">{post.authorTitle}</p>
                </div>
              </div>
              
              <div className="flex gap-4">
                <span className="flex items-center">
                  <Calendar className="h-4 w-4 mr-1 text-gold/70" /> {post.date}
                </span>
                <span className="flex items-center">
                  <Clock className="h-4 w-4 mr-1 text-gold/70" /> {post.readTime}
                </span>
              </div>
            </div>
            
            <div className="prose prose-invert prose-gold max-w-none">
              {post.content.map((paragraph, index) => (
                <React.Fragment key={index}>
                  {paragraph.type === 'paragraph' && <p>{paragraph.text}</p>}
                  {paragraph.type === 'heading' && <h2 className="text-xl font-bold text-gold mt-8 mb-4">{paragraph.text}</h2>}
                  {paragraph.type === 'list' && (
                    <ul className="list-disc pl-6 my-4">
                      {paragraph.items.map((item, itemIndex) => (
                        <li key={itemIndex} className="mb-2">{item}</li>
                      ))}
                    </ul>
                  )}
                  {paragraph.type === 'quote' && (
                    <blockquote className="border-l-4 border-gold pl-4 italic my-6">
                      {paragraph.text}
                    </blockquote>
                  )}
                  {paragraph.type === 'image' && (
                    <div className="my-8">
                      <img 
                        src={paragraph.url} 
                        alt={paragraph.caption || ''} 
                        className="w-full rounded-lg" 
                      />
                      {paragraph.caption && (
                        <p className="text-center text-sm text-gray-400 mt-2">{paragraph.caption}</p>
                      )}
                    </div>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
        
        <div className="mt-12">
          <h3 className="text-xl font-bold text-gold mb-6">Related Articles</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {blogPosts
              .filter(relatedPost => relatedPost.id !== id && relatedPost.category === post.category)
              .slice(0, 3)
              .map((relatedPost, index) => (
                <div key={index} className="glass-card overflow-hidden hover:shadow-lg hover:shadow-gold/10 transition-all duration-300">
                  <div className="h-40 overflow-hidden">
                    <img 
                      src={relatedPost.imageUrl} 
                      alt={relatedPost.title} 
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" 
                    />
                  </div>
                  <div className="p-4">
                    <h4 className="text-lg font-bold text-gold mb-2 line-clamp-2">{relatedPost.title}</h4>
                    <button 
                      onClick={() => navigate(`/blog/${relatedPost.id}`)}
                      className="text-gold hover:text-gold-light transition-colors flex items-center text-sm font-medium"
                    >
                      Read Article <span className="ml-2">→</span>
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default BlogPostPage;
