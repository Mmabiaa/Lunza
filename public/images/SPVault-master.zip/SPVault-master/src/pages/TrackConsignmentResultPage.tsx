import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

interface Consignment {
  id: string;
  productName: string;
  quantity: number;
  unit: string;
  dateOfEntry: string;
  depositedBy: string;
  witness: string;
  entryType: string;
  status: 'PENDING' | 'IN_TRANSIT' | 'DELIVERED' | 'CANCELLED';
  trackingNumber: string;
  currentLocation: string;
  lastUpdate: string;
}

const TrackConsignmentResultPage: React.FC = () => {
  const { trackingNumber } = useParams<{ trackingNumber: string }>();
  const navigate = useNavigate();

  // Sample consignment data - In a real app, this would come from an API
  const consignment: Consignment = {
    id: '1',
    productName: 'ALLUVIAL GOLD',
    quantity: 75,
    unit: 'kg',
    dateOfEntry: '05/03/2016',
    depositedBy: 'Bernard Kearns',
    witness: 'Attorney John Wilson',
    entryType: 'Storage + insurance',
    status: 'DELIVERED',
    trackingNumber: 'LM498039123SPV',
    currentLocation: 'SP Vault Storage Facility',
    lastUpdate: '05/03/2016'
  };

  const getStatusColor = (status: Consignment['status']) => {
    switch (status) {
      case 'PENDING':
        return 'bg-yellow-500';
      case 'IN_TRANSIT':
        return 'bg-blue-500';
      case 'DELIVERED':
        return 'bg-green-500';
      case 'CANCELLED':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  if (trackingNumber !== consignment.trackingNumber) {
    return (
      <div className="min-h-screen bg-navy-dark text-white">
        <Navbar />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-3xl font-bold mb-8">Tracking Number Not Found</h1>
            <p className="text-gray-300 mb-8">The tracking number you entered could not be found. Please check the number and try again.</p>
            <button
              onClick={() => navigate('/track-consignment')}
              className="btn-gold"
            >
              Try Again
            </button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-dark text-white">
      <Navbar />
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="bg-navy-light rounded-lg shadow-xl overflow-hidden">
            <div className="p-8">
              <div className="flex items-center justify-between mb-8">
                <h1 className="text-3xl font-bold">Consignment Details</h1>
                <span className={`px-4 py-2 rounded-full text-sm font-semibold ${getStatusColor(consignment.status)}`}>
                  {consignment.status.replace('_', ' ')}
                </span>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-navy-dark/50 p-6 rounded-lg">
                    <h2 className="text-xl font-semibold mb-4 text-gold">Consignment Information</h2>
                    <div className="space-y-4">
                      <div>
                        <p className="text-gray-400">Product</p>
                        <p className="text-lg">{consignment.quantity}{consignment.unit} of {consignment.productName}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Date of Entry</p>
                        <p className="text-lg">{consignment.dateOfEntry}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Deposited By</p>
                        <p className="text-lg">{consignment.depositedBy}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Witness</p>
                        <p className="text-lg">{consignment.witness}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Entry Type</p>
                        <p className="text-lg">{consignment.entryType}</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-navy-dark/50 p-6 rounded-lg">
                    <h2 className="text-xl font-semibold mb-4 text-gold">Tracking Information</h2>
                    <div className="space-y-4">
                      <div>
                        <p className="text-gray-400">Tracking Number</p>
                        <p className="text-lg">{consignment.trackingNumber}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Current Location</p>
                        <p className="text-lg">{consignment.currentLocation}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Last Update</p>
                        <p className="text-lg">{consignment.lastUpdate}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-8 flex justify-center">
                <button
                  onClick={() => navigate('/track-consignment')}
                  className="btn-gold"
                >
                  Track Another Consignment
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default TrackConsignmentResultPage; 