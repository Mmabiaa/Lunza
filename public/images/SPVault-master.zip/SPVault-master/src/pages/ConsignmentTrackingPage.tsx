import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

interface Consignment {
  id: string;
  productName: string;
  quantity: number;
  unit: string;
  dateOfEntry: string;
  depositedBy: string;
  witness: string;
  entryType: string;
  status: 'PENDING' | 'IN_TRANSIT' | 'DELIVERED' | 'CANCELLED';
  trackingNumber: string;
  currentLocation: string;
  lastUpdate: string;
}

const ConsignmentTrackingPage = () => {
  const [trackingNumber, setTrackingNumber] = useState('');
  const [showConsignment, setShowConsignment] = useState(false);
  const [error, setError] = useState('');
  
  const consignment: Consignment = {
    id: '1',
    productName: 'ALLUVIAL GOLD',
    quantity: 75,
    unit: 'kg',
    dateOfEntry: '05/03/2016',
    depositedBy: 'Bernard Kearns',
    witness: 'Attorney John Wilson',
    entryType: 'Storage + insurance',
    status: 'IN_TRANSIT',
    trackingNumber: 'LM498039123SPV',
    currentLocation: 'London Distribution Center',
    lastUpdate: '2024-03-15 14:30:00'
  };

  const handleTrackConsignment = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!trackingNumber.trim()) {
      setError('Please enter a tracking number');
      setShowConsignment(false);
      return;
    }

    if (trackingNumber === consignment.trackingNumber) {
      setShowConsignment(true);
    } else {
      setError('Invalid tracking number');
      setShowConsignment(false);
    }
  };

  const getStatusColor = (status: Consignment['status']) => {
    switch (status) {
      case 'PENDING':
        return 'bg-yellow-400/20 text-yellow-400';
      case 'IN_TRANSIT':
        return 'bg-blue-400/20 text-blue-400';
      case 'DELIVERED':
        return 'bg-green-400/20 text-green-400';
      case 'CANCELLED':
        return 'bg-red-400/20 text-red-400';
      default:
        return 'bg-gray-400/20 text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-navy-dark text-white">
      <Navbar />
      
      {/* Hero Section */}
      <div className="relative h-[40vh] bg-navy-light flex items-center justify-center">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-navy-dark"></div>
        <div className="relative z-10 text-center">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-gold mb-4">Consignment Tracking</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Track your precious metals consignments in real-time with our secure tracking system
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Tracking Form */}
          <div className="lg:col-span-1">
            <div className="bg-navy-light rounded-lg p-6 border border-gold/20 sticky top-8">
              <h2 className="text-2xl font-playfair font-bold text-gold mb-6">Track Consignment</h2>
              <form onSubmit={handleTrackConsignment} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Tracking Number
                  </label>
                  <input
                    type="text"
                    value={trackingNumber}
                    onChange={(e) => {
                      setTrackingNumber(e.target.value);
                      setError('');
                      setShowConsignment(false);
                    }}
                    placeholder="Enter tracking number"
                    className="w-full bg-navy-dark text-white border border-gold/20 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-gold"
                  />
                  {error && (
                    <p className="mt-2 text-sm text-red-400">{error}</p>
                  )}
                </div>
                <button
                  type="submit"
                  className="w-full bg-gold text-navy-dark font-bold py-3 rounded-md hover:bg-gold/90 transition-colors duration-300"
                >
                  Track Consignment
                </button>
              </form>
            </div>
          </div>

          {/* Consignment Details */}
          <div className="lg:col-span-2">
            {showConsignment ? (
              <div className="bg-navy-light rounded-lg p-6 border border-gold/20">
                <h2 className="text-2xl font-playfair font-bold text-gold mb-6">Consignment Details</h2>
                <div className="bg-navy-dark rounded-lg p-6 border border-gold/20">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gold mb-2">{consignment.productName}</h3>
                      <p className="text-gray-400">Tracking Number: {consignment.trackingNumber}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm ${getStatusColor(consignment.status)}`}>
                      {consignment.status.replace('_', ' ')}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-gray-400 text-sm">Quantity</p>
                      <p className="text-white">{consignment.quantity} {consignment.unit}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Date of Entry</p>
                      <p className="text-white">{consignment.dateOfEntry}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Deposited By</p>
                      <p className="text-white">{consignment.depositedBy}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Witness</p>
                      <p className="text-white">{consignment.witness}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Entry Type</p>
                      <p className="text-white">{consignment.entryType}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Current Location</p>
                      <p className="text-white">{consignment.currentLocation}</p>
                    </div>
                  </div>
                  <div className="text-sm text-gray-400">
                    Last Update: {consignment.lastUpdate}
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-navy-light rounded-lg p-6 border border-gold/20 text-center">
                <p className="text-gray-400">Enter a tracking number and click Track Consignment to view details</p>
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ConsignmentTrackingPage; 