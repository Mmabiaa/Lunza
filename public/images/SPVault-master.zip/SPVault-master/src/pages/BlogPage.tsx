import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { Search, FileText, User, Clock, Calendar } from 'lucide-react';
import { blogPosts } from '../data/blogPosts';

const BlogPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const navigate = useNavigate();
  
  // Extract all unique categories from blog posts
  const allCategories = ['All', ...new Set(blogPosts.map(post => post.category))];
  
  // Find the featured post (first in the array)
  const featuredPost = {
    id: "featured",
    title: "The Future of Gold Investment in a Digital World",
    description: "Exploring how digital transformation is reshaping gold investment strategies while maintaining the timeless value of physical gold.",
    excerpt: "Exploring how digital transformation is reshaping gold investment strategies...",
    date: "May 20, 2025",
    readTime: "10 min",
    author: "David Wilson",
    authorTitle: "Investment Strategist",
    category: "Investment Strategy",
    imageUrl: "https://i.pinimg.com/736x/0c/32/54/0c3254e4e3ccd350aef61a934cc5f763.jpg"
  };
  
  // Filter posts based on search term and active category
  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'All' || post.category === activeCategory;
    return matchesSearch && matchesCategory;
  });
  
  // Also check if featured post should be shown
  const showFeaturedPost = (activeCategory === 'All' || featuredPost.category === activeCategory) &&
                           (featuredPost.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            featuredPost.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            searchTerm === '');

  return (
    <div className="min-h-screen bg-navy text-white">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gold mb-4">Gold Investment Blog</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto mb-8">
            Expert insights, market analysis, and educational content to help you make informed gold investment decisions.
          </p>
          
          <div className="max-w-xl mx-auto relative mb-10">
            <input
              type="text"
              placeholder="Search articles..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-navy-light border border-gold/30 rounded-full px-6 py-3 pr-12 focus:outline-none focus:border-gold text-white"
            />
            <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gold/70 h-5 w-5" />
          </div>
          
          <div className="flex flex-wrap justify-center gap-2 mb-10">
            {allCategories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  activeCategory === category 
                    ? 'bg-gold text-navy-dark' 
                    : 'bg-navy-light text-gray-300 hover:bg-gold/20'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        
        {/* Featured Post */}
        {showFeaturedPost && (
          <div className="glass-card overflow-hidden mb-16">
            <div className="md:flex">
              <div className="md:w-1/2">
                <img 
                  src={featuredPost.imageUrl} 
                  alt={featuredPost.title} 
                  className="w-full h-full object-cover" 
                />
              </div>
              <div className="md:w-1/2 p-8 flex flex-col justify-center">
                <div className="flex items-center gap-3 mb-4">
                  <span className="bg-gold/20 text-gold px-3 py-1 rounded-full text-xs font-medium">
                    Featured
                  </span>
                  <span className="bg-navy-light px-3 py-1 rounded-full text-xs font-medium text-gray-300">
                    {featuredPost.category}
                  </span>
                </div>
                <h2 className="text-2xl md:text-3xl font-bold text-gold mb-3">{featuredPost.title}</h2>
                <p className="text-gray-300 mb-4">{featuredPost.excerpt}</p>
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center text-sm text-gray-400 mb-6 gap-2">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-navy-light rounded-full flex items-center justify-center mr-2">
                      <User className="h-4 w-4 text-gold/70" />
                    </div>
                    <div>
                      <p className="font-medium text-white">{featuredPost.author}</p>
                      <p className="text-xs">{featuredPost.authorTitle}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" /> {featuredPost.date}
                    </span>
                    <span className="flex items-center">
                      <Clock className="h-3 w-3 mr-1" /> {featuredPost.readTime}
                    </span>
                  </div>
                </div>
                <button 
                  onClick={() => navigate(`/blog/${featuredPost.id}`)}
                  className="btn-gold self-start"
                >
                  Read Full Article
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Blog Posts Grid */}
        {filteredPosts.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-gray-400 text-lg">No articles found matching your search. Please try different keywords or categories.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.filter(post => post.id !== featuredPost.id).map((post, index) => (
              <div key={index} className="glass-card overflow-hidden hover:shadow-lg hover:shadow-gold/10 transition-all duration-300">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={post.imageUrl} 
                    alt={post.title} 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" 
                  />
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-center mb-3">
                    <span className="bg-navy-light px-3 py-1 rounded-full text-xs font-medium text-gray-300">
                      {post.category}
                    </span>
                    <span className="text-gray-400 text-sm">{post.date}</span>
                  </div>
                  <h3 className="text-xl font-bold text-gold mb-2">{post.title}</h3>
                  <p className="text-gray-400 mb-4 line-clamp-3">{post.excerpt}</p>
                  <div className="flex justify-between items-center text-sm text-gray-400 mb-4">
                    <span>{post.author}</span>
                    <span className="flex items-center"><FileText className="h-3 w-3 mr-1" /> {post.readTime}</span>
                  </div>
                  <button 
                    onClick={() => navigate(`/blog/${post.id}`)}
                    className="text-gold hover:text-gold-light transition-colors flex items-center text-sm font-medium"
                  >
                    Read Article <span className="ml-2">→</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default BlogPage;
