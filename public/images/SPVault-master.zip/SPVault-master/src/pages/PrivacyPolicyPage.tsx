import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const PrivacyPolicyPage = () => {
  const lastUpdated = "May 1, 2025";

  return (
    <div className="min-h-screen bg-navy text-white">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-10">
          <h1 className="text-4xl font-bold text-gold mb-2">Privacy Policy</h1>
          <p className="text-gray-400">Last Updated: {lastUpdated}</p>
        </div>
        
        <div className="prose prose-lg prose-invert prose-gold max-w-none">
          <p>
            At SP VAULT, we respect your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Information We Collect</h2>
          
          <h3 className="text-xl font-semibold mt-6 mb-3">Personal Information</h3>
          <p>
            We may collect personal information that you voluntarily provide to us when you:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Register for an account</li>
            <li>Purchase products or services</li>
            <li>Sign up for our newsletter</li>
            <li>Contact our customer service</li>
            <li>Complete surveys or provide feedback</li>
            <li>Participate in promotions or contests</li>
          </ul>
          
          <p className="mt-4">
            This information may include your name, email address, mailing address, phone number, payment information, and other details about yourself.
          </p>
          
          <h3 className="text-xl font-semibold mt-6 mb-3">Automatically Collected Information</h3>
          <p>
            When you visit our website, we may automatically collect certain information about your device and your interaction with our website, including:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Log and usage data (IP address, browser type, operating system)</li>
            <li>Device information</li>
            <li>Location information</li>
            <li>Cookies and tracking technologies</li>
          </ul>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">How We Use Your Information</h2>
          <p>
            We may use the information we collect for various purposes, including:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Providing and maintaining our services</li>
            <li>Processing transactions and sending related information</li>
            <li>Responding to inquiries and providing customer support</li>
            <li>Sending administrative information</li>
            <li>Sending marketing and promotional communications</li>
            <li>Personalizing your experience</li>
            <li>Protecting our services and users</li>
            <li>Complying with legal obligations</li>
          </ul>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Information Sharing and Disclosure</h2>
          <p>
            We may share your information in the following situations:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>With service providers who perform services on our behalf</li>
            <li>With business partners with your consent</li>
            <li>In connection with a business transaction (merger, sale, etc.)</li>
            <li>To comply with legal obligations</li>
            <li>To protect our rights, privacy, safety, or property</li>
          </ul>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Your Privacy Rights</h2>
          <p>
            Depending on your location, you may have certain rights regarding your personal information, such as:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Right to access your personal information</li>
            <li>Right to correct inaccurate information</li>
            <li>Right to request deletion of your information</li>
            <li>Right to restrict or object to processing</li>
            <li>Right to data portability</li>
            <li>Right to withdraw consent</li>
          </ul>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Security Measures</h2>
          <p>
            We implement appropriate technical and organizational measures to protect your personal information from unauthorized access, disclosure, alteration, or destruction. However, no electronic transmission or storage of information can be entirely secure, so we cannot guarantee absolute security.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Children's Privacy</h2>
          <p>
            Our services are not directed to children under the age of 18. We do not knowingly collect personal information from children. If we discover that a child has provided us with personal information, we will promptly delete it.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Changes to This Privacy Policy</h2>
          <p>
            We may update this Privacy Policy from time to time. The updated version will be indicated by an updated "Last Updated" date at the top of this page. We encourage you to review this Privacy Policy frequently to stay informed about how we are protecting your information.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Contact Us</h2>
          <p>
            If you have questions or comments about this Privacy Policy, please contact us at:
          </p>
          <div className="mt-2">
            <p>Email: privacy@spvault.com</p>
            <p>Phone: +44 7441922094</p>
            <p>Address: UK Office, London, United Kingdom</p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default PrivacyPolicyPage;
