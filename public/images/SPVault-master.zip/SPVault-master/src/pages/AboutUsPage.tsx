import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

interface TeamMember {
  id: string;
  name: string;
  position: string;
  bio: string;
  imageUrl: string;
}

const teamMembers: TeamMember[] = [
  {
    id: '1',
    name: 'John Smith',
    position: 'Chief Executive Officer',
    bio: 'With over 20 years of experience in precious metals trading and investment management.',
    imageUrl: 'https://i.pinimg.com/736x/0a/c9/89/0ac989fbdfc51c421015625b35f8d686.jpg'
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    position: 'Chief Financial Officer',
    bio: 'Former investment banker with expertise in wealth management and financial strategy.',
    imageUrl: 'https://i.pinimg.com/736x/9a/a0/bc/9aa0bc99645d66f1949ddefa3f700d0f.jpg'
  },
  {
    id: '3',
    name: 'Michael Dankwah',
    position: 'Head of Trading',
    bio: 'Specialized in precious metals trading with a focus on market analysis and risk management.',
    imageUrl: 'https://i.pinimg.com/736x/3c/ec/3b/3cec3b2a81ef09c854b4d4d39d050ec0.jpg'
  },
  {
    id: '4',
    name: 'Emily Davis',
    position: 'Client Relations Director',
    bio: 'Dedicated to providing exceptional service and building long-term client relationships.',
    imageUrl: 'https://i.pinimg.com/736x/5e/87/00/5e8700424201eb225c9a7dea4c3ec7f4.jpg'
  }
];

const AboutUsPage = () => {
  return (
    <div className="min-h-screen bg-navy-dark text-white">
      <Navbar />
      {/* Hero Section */}
      <div className="relative h-[40vh] bg-navy-light flex items-center justify-center">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-navy-dark"></div>
        <div className="relative z-10 text-center">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-gold mb-4">About SP VAULT</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Your trusted partner in precious metals investment and wealth preservation
          </p>
        </div>
      </div>

      {/* Mission Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-playfair font-bold text-gold mb-6">Our Mission</h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            At SP VAULT, we are committed to providing our clients with the highest quality precious metals investment solutions, 
            backed by exceptional service and expertise. Our mission is to help individuals and institutions preserve and grow their wealth 
            through secure and transparent precious metals investments.
          </p>
        </div>

        {/* Values Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="bg-navy-light p-8 rounded-lg border border-gold/20">
            <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mb-6">
              <svg className="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <h3 className="text-xl font-playfair font-bold text-gold mb-4">Security</h3>
            <p className="text-gray-400">
              We prioritize the security of your investments with state-of-the-art storage facilities and robust security measures.
            </p>
          </div>
          <div className="bg-navy-light p-8 rounded-lg border border-gold/20">
            <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mb-6">
              <svg className="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <h3 className="text-xl font-playfair font-bold text-gold mb-4">Transparency</h3>
            <p className="text-gray-400">
              We believe in complete transparency in all our operations, from pricing to storage and delivery.
            </p>
          </div>
          <div className="bg-navy-light p-8 rounded-lg border border-gold/20">
            <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mb-6">
              <svg className="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
              </svg>
            </div>
            <h3 className="text-xl font-playfair font-bold text-gold mb-4">Expertise</h3>
            <p className="text-gray-400">
              Our team of experts provides valuable insights and guidance to help you make informed investment decisions.
            </p>
          </div>
        </div>

        {/* Team Section */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-playfair font-bold text-gold mb-6">Our Leadership Team</h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Meet the experienced professionals who lead our company with vision and expertise
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member) => (
            <div key={member.id} className="bg-navy-light rounded-lg overflow-hidden border border-gold/20">
              <div className="aspect-w-1 aspect-h-1">
                <img
                  src={member.imageUrl}
                  alt={member.name}
                  className="object-cover w-full h-full"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-playfair font-bold text-gold mb-2">{member.name}</h3>
                <p className="text-gold/80 mb-4">{member.position}</p>
                <p className="text-gray-400 text-sm">{member.bio}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default AboutUsPage; 