import React from 'react';

const ProductsPage = () => {
  const products = [
    {
      id: 'gold-bullion',
      title: 'Gold Bullion',
      description: 'High-quality gold bars and coins from trusted mints worldwide.',
      features: [
        '99.99% pure gold',
        'Internationally recognized brands',
        'Competitive pricing',
        'Secure storage options'
      ],
      imageUrl: 'https://images.unsplash.com/photo-1574362848149-11496d93a7c7?auto=format&fit=crop&q=80&w=2084'
    },
    {
      id: 'silver-bullion',
      title: 'Silver Bullion',
      description: 'Premium silver products for investment and collection.',
      features: [
        '99.9% pure silver',
        'Various sizes available',
        'Government minted coins',
        'Private mint options'
      ],
      imageUrl: 'https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&q=80&w=2070'
    },
    {
      id: 'platinum-bullion',
      title: 'Platinum Bullion',
      description: 'Rare and valuable platinum investment products.',
      features: [
        '99.95% pure platinum',
        'Limited availability',
        'High investment potential',
        'Professional storage solutions'
      ],
      imageUrl: 'https://images.unsplash.com/photo-1589758438368-0ad531db3366?auto=format&fit=crop&q=80&w=2232'
    },
    {
      id: 'storage-solutions',
      title: 'Storage Solutions',
      description: 'Secure storage options for your precious metals.',
      features: [
        'Allocated storage',
        'Segregated storage',
        'Insurance included',
        '24/7 security monitoring'
      ],
      imageUrl: 'https://images.unsplash.com/photo-1633265486501-0cf524a07213?auto=format&fit=crop&q=80&w=2070'
    }
  ];

  return (
    <div className="min-h-screen bg-navy-dark">
      {/* Hero Section */}
      <div className="relative bg-navy-dark py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-playfair font-bold text-gold mb-4">
              Our Premium Products
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Discover our carefully curated selection of precious metals and secure storage solutions,
              designed to meet the needs of both seasoned investors and newcomers to the market.
            </p>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {products.map((product) => (
            <div
              key={product.id}
              className="bg-navy-light rounded-lg overflow-hidden shadow-lg transform transition duration-500 hover:scale-105"
            >
              <div className="relative h-64">
                <img
                  src={product.imageUrl}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-dark to-transparent" />
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-playfair font-bold text-gold mb-2">
                  {product.title}
                </h3>
                <p className="text-gray-300 mb-4">
                  {product.description}
                </p>
                <ul className="space-y-2">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-gray-400">
                      <svg
                        className="h-5 w-5 text-gold mr-2"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                      {feature}
                    </li>
                  ))}
                </ul>
                <button className="mt-6 w-full bg-gold text-navy-dark font-semibold py-2 px-4 rounded hover:bg-gold/90 transition-colors">
                  Learn More
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductsPage; 