import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { Search, FileText, BookOpen } from 'lucide-react';

interface Guide {
  id: string;
  title: string;
  description: string;
  category: string;
  readTime: string;
  content: string;
  imageUrl: string;
}

const InvestmentGuidesPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGuide, setSelectedGuide] = useState<Guide | null>(null);
  const [activeCategory, setActiveCategory] = useState('All');

  const guides: Guide[] = [
    {
      id: '1',
      title: 'Getting Started with Gold Investment',
      description: 'A comprehensive guide for beginners looking to start their gold investment journey.',
      category: 'Beginner',
      readTime: '10 min',
      content: `# Getting Started with Gold Investment

## Introduction
Gold has been a valuable asset for centuries, serving as both a store of value and a hedge against economic uncertainty. This guide will help you understand the basics of gold investment and how to get started.

## Why Invest in Gold?
- Hedge against inflation
- Portfolio diversification
- Safe haven asset
- Long-term value preservation

## Types of Gold Investments
1. Physical Gold
   - Gold bars
   - Gold coins
   - Gold jewelry

2. Paper Gold
   - Gold ETFs
   - Gold futures
   - Gold mining stocks

## Getting Started
1. Set your investment goals
2. Determine your budget
3. Choose your preferred investment method
4. Select a reputable dealer
5. Make your first purchase

## Storage Options
- Home storage
- Bank safe deposit boxes
- Professional vault storage

## Conclusion
Gold investment can be a valuable addition to your portfolio. Start small, learn continuously, and make informed decisions based on your financial goals.`,
      imageUrl: 'https://i.pinimg.com/736x/0c/32/54/0c3254e4e3ccd350aef61a934cc5f763.jpg'
    },
    {
      id: '2',
      title: 'Advanced Gold Trading Strategies',
      description: 'Learn sophisticated trading techniques for experienced investors.',
      category: 'Advanced',
      readTime: '15 min',
      content: `# Advanced Gold Trading Strategies

## Introduction
This guide explores advanced trading strategies for experienced gold investors looking to maximize their returns.

## Technical Analysis
- Chart patterns
- Moving averages
- RSI indicators
- Fibonacci retracements

## Fundamental Analysis
- Supply and demand factors
- Central bank policies
- Economic indicators
- Geopolitical events

## Trading Strategies
1. Swing Trading
2. Position Trading
3. Scalping
4. Hedging

## Risk Management
- Position sizing
- Stop-loss orders
- Portfolio allocation
- Risk-reward ratios

## Market Timing
- Seasonal patterns
- Market cycles
- Entry and exit points

## Conclusion
Advanced trading requires discipline, knowledge, and continuous learning. Always practice risk management and stay informed about market developments.`,
      imageUrl: 'https://i.pinimg.com/736x/64/67/0d/64670deef4d02f99791f8178530e0b40.jpg'
    },
    {
      id: '3',
      title: 'Gold Storage and Security Guide',
      description: 'Essential information about storing and securing your gold investments.',
      category: 'Security',
      readTime: '12 min',
      content: `# Gold Storage and Security Guide

## Introduction
Proper storage and security are crucial aspects of gold investment. This guide covers various storage options and security measures.

## Storage Options
1. Home Storage
   - Safes
   - Hidden compartments
   - Security systems

2. Professional Storage
   - Vaults
   - Depositories
   - Allocated storage

3. Bank Storage
   - Safe deposit boxes
   - Private vaults

## Security Measures
- Insurance coverage
- Security systems
- Access controls
- Regular audits

## Best Practices
1. Documentation
2. Insurance
3. Regular verification
4. Security protocols

## Conclusion
Choose storage options based on your investment size, security requirements, and accessibility needs. Always prioritize security and proper documentation.`,
      imageUrl: 'https://i.pinimg.com/736x/20/31/3c/20313ca6492e9b2df38b93911d7e23fb.jpg'
    }
  ];

  const categories = ['All', ...new Set(guides.map(guide => guide.category))];

  const filteredGuides = guides.filter(guide => {
    const matchesSearch = guide.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         guide.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'All' || guide.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-navy-dark text-white">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gold mb-4">Investment Guides</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Comprehensive guides to help you make informed decisions about your gold investments
          </p>
        </div>

        {!selectedGuide ? (
          <>
            <div className="max-w-xl mx-auto relative mb-10">
              <input
                type="text"
                placeholder="Search guides..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-navy-light border border-gold/30 rounded-full px-6 py-3 pr-12 focus:outline-none focus:border-gold text-white"
              />
              <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gold/70 h-5 w-5" />
            </div>

            <div className="flex flex-wrap justify-center gap-2 mb-10">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    activeCategory === category 
                      ? 'bg-gold text-navy-dark' 
                      : 'bg-navy-light text-gray-300 hover:bg-gold/20'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredGuides.map((guide) => (
                <div 
                  key={guide.id}
                  className="glass-card overflow-hidden hover:shadow-lg hover:shadow-gold/10 transition-all duration-300 cursor-pointer"
                  onClick={() => setSelectedGuide(guide)}
                >
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={guide.imageUrl} 
                      alt={guide.title} 
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" 
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex justify-between items-center mb-3">
                      <span className="bg-navy-light px-3 py-1 rounded-full text-xs font-medium text-gray-300">
                        {guide.category}
                      </span>
                      <span className="text-gray-400 text-sm flex items-center">
                        <BookOpen className="h-3 w-3 mr-1" /> {guide.readTime}
                      </span>
                    </div>
                    <h3 className="text-xl font-bold text-gold mb-2">{guide.title}</h3>
                    <p className="text-gray-400 mb-4">{guide.description}</p>
                    <button className="text-gold hover:text-gold-light transition-colors flex items-center text-sm font-medium">
                      Read Guide <span className="ml-2">→</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          <div className="max-w-4xl mx-auto">
            <button
              onClick={() => setSelectedGuide(null)}
              className="text-gold hover:text-gold-light transition-colors flex items-center text-sm font-medium mb-6"
            >
              ← Back to Guides
            </button>
            <div className="glass-card p-8">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-3xl font-bold text-gold">{selectedGuide.title}</h2>
                <span className="bg-navy-light px-3 py-1 rounded-full text-sm font-medium text-gray-300">
                  {selectedGuide.category}
                </span>
              </div>
              <div className="prose prose-invert max-w-none">
                {selectedGuide.content.split('\n').map((line, index) => {
                  if (line.startsWith('# ')) {
                    return <h1 key={index} className="text-2xl font-bold text-gold mt-6 mb-4">{line.substring(2)}</h1>;
                  } else if (line.startsWith('## ')) {
                    return <h2 key={index} className="text-xl font-bold text-gold mt-5 mb-3">{line.substring(3)}</h2>;
                  } else if (line.startsWith('- ')) {
                    return <li key={index} className="text-gray-300 ml-4 mb-2">{line.substring(2)}</li>;
                  } else if (line.startsWith('1. ')) {
                    return <li key={index} className="text-gray-300 ml-4 mb-2">{line.substring(3)}</li>;
                  } else if (line.trim() === '') {
                    return <br key={index} />;
                  } else {
                    return <p key={index} className="text-gray-300 mb-4">{line}</p>;
                  }
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default InvestmentGuidesPage;
