
import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { ChartBar, Download } from 'lucide-react';
import { 
  ChartContainer, 
  ChartTooltip,
  ChartTooltipContent
} from '@/components/ui/chart';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  ResponsiveContainer,
  Legend 
} from 'recharts';
import { toast } from "sonner";

// Mock data for chart demonstrations - in a real app, this would come from an API
const getLiveGoldData = () => {
  const today = new Date();
  const data = [];
  
  // Generate 24 hours of mock data
  for (let i = 0; i < 24; i++) {
    const time = new Date(today);
    time.setHours(time.getHours() - 23 + i);
    
    // Base price with slight randomization
    const basePrice = 1925 + (Math.random() * 20 - 10);
    
    data.push({
      time: time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      price: parseFloat(basePrice.toFixed(2)),
      date: time.toLocaleDateString(),
    });
  }
  
  return data;
};

const getHistoricalGoldData = (months = 6) => {
  const today = new Date();
  const data = [];
  
  // Generate monthly data
  for (let i = 0; i <= months; i++) {
    const date = new Date(today);
    date.setMonth(date.getMonth() - months + i);
    
    // Base price with trend
    const trend = i * 15; // Upward trend
    const basePrice = 1850 + trend + (Math.random() * 40 - 20);
    
    data.push({
      month: date.toLocaleDateString([], { month: 'short', year: 'numeric' }),
      price: parseFloat(basePrice.toFixed(2)),
      date: date.toLocaleDateString(),
    });
  }
  
  return data;
};

// Generate currency comparison data
const getCurrencyComparisonData = () => {
  const currencies = ['USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD', 'CHF'];
  const baseOuncePrice = 1925;
  const date = new Date().toLocaleDateString();
  
  return currencies.map(currency => {
    const exchangeRates = {
      USD: 1,
      EUR: 0.92,
      GBP: 0.79,
      JPY: 150.25,
      CAD: 1.37,
      AUD: 1.52,
      CHF: 0.89
    };
    
    return {
      currency,
      price: parseFloat((baseOuncePrice * exchangeRates[currency]).toFixed(2)),
      date
    };
  });
};

// Generate commodities comparison data
const getCommoditiesData = () => {
  const today = new Date();
  const monthsAgo = new Date(today);
  monthsAgo.setMonth(monthsAgo.getMonth() - 12);
  
  // Ratio of gold to other commodities (approximate)
  const commodities = [
    { name: 'Gold', color: '#FFD700', ratio: 1 },
    { name: 'Silver', color: '#C0C0C0', ratio: 0.012 },
    { name: 'Platinum', color: '#E5E4E2', ratio: 0.9 },
    { name: 'Palladium', color: '#CBA135', ratio: 0.7 },
    { name: 'Oil (barrel)', color: '#000000', ratio: 0.02 }
  ];
  
  // Generate monthly data points for the past year
  const months = 12;
  const baseGoldPrice = 1900;
  
  return commodities.map(commodity => {
    const data = [];
    
    for (let i = 0; i <= months; i++) {
      const date = new Date(monthsAgo);
      date.setMonth(date.getMonth() + i);
      
      // Add some random fluctuation
      const fluctuation = (Math.random() * 0.1) - 0.05; // +/- 5%
      const priceRatio = commodity.ratio * (1 + fluctuation);
      const price = baseGoldPrice * priceRatio;
      
      data.push({
        month: date.toLocaleDateString([], { month: 'short', year: 'numeric' }),
        price: parseFloat(price.toFixed(2)),
        commodity: commodity.name
      });
    }
    
    return {
      name: commodity.name,
      color: commodity.color,
      data
    };
  });
};

const GoldPriceChartsPage = () => {
  const [activeChartIndex, setActiveChartIndex] = useState(0);
  const [activeTimeframe, setActiveTimeframe] = useState('1D');
  const [liveGoldData, setLiveGoldData] = useState(getLiveGoldData());
  const [historicalData, setHistoricalData] = useState(getHistoricalGoldData(6));
  const [currencyData, setCurrencyData] = useState(getCurrencyComparisonData());
  const [commoditiesData, setCommoditiesData] = useState(getCommoditiesData());
  
  const chartTypes = [
    {
      title: "Live Gold Price Chart",
      description: "Track real-time gold prices with minute-by-minute updates and interactive controls.",
      timeframes: ["1D", "1W", "1M", "3M", "6M", "1Y", "5Y", "MAX"]
    },
    {
      title: "Historical Gold Price Trends",
      description: "Analyze long-term gold price performance and identify market patterns over time.",
      timeframes: ["1Y", "5Y", "10Y", "20Y", "50Y", "100Y"]
    },
    {
      title: "Gold to Currency Ratio Charts",
      description: "Compare gold prices against major world currencies including USD, EUR, GBP, JPY, and more.",
      timeframes: ["1M", "3M", "6M", "1Y", "5Y"]
    },
    {
      title: "Gold vs Other Commodities",
      description: "Benchmark gold performance against silver, platinum, oil, and other major commodities.",
      timeframes: ["1M", "3M", "6M", "1Y", "5Y"]
    }
  ];

  // Update live gold data every 30 seconds
  useEffect(() => {
    const intervalId = setInterval(() => {
      setLiveGoldData(getLiveGoldData());
    }, 30000);
    
    return () => clearInterval(intervalId);
  }, []);
  
  // Handle timeframe selection
  const handleTimeframeChange = (chartIndex, timeframe) => {
    setActiveChartIndex(chartIndex);
    setActiveTimeframe(timeframe);
    
    // Update data based on selected timeframe
    if (chartIndex === 0) { // Live Gold Price Chart
      if (timeframe === "1D") {
        setLiveGoldData(getLiveGoldData());
      } else if (timeframe === "1W") {
        // In a real app, you would fetch weekly data
        toast("Fetching weekly price data...");
      } else {
        toast("Fetching historical data for " + timeframe);
      }
    } else if (chartIndex === 1) { // Historical Trends
      if (timeframe === "1Y") {
        setHistoricalData(getHistoricalGoldData(12));
      } else if (timeframe === "5Y") {
        setHistoricalData(getHistoricalGoldData(60));
      } else {
        toast("Fetching " + timeframe + " historical data...");
      }
    }
  };
  
  // Handle download data
  const handleDownloadData = (chartIndex) => {
    toast.success("Preparing data download...");
    
    // In a real app, this would generate and download a CSV/Excel file
    setTimeout(() => {
      toast.success("Data downloaded successfully!");
    }, 1500);
  };
  
  const renderChartContent = (chartIndex) => {
    const chartConfig = {
      gold: { color: "#FFD700", label: "Gold Price" },
      silver: { color: "#C0C0C0", label: "Silver" },
      platinum: { color: "#E5E4E2", label: "Platinum" },
      oil: { color: "#000000", label: "Oil" },
      palladium: { color: "#CBA135", label: "Palladium" },
    };
    
    switch (chartIndex) {
      case 0: // Live Gold Price Chart
        return (
          <ChartContainer config={chartConfig} className="h-80 w-full">
            <LineChart data={liveGoldData} margin={{ top: 20, right: 30, left: 20, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#555" />
              <XAxis 
                dataKey="time" 
                tick={{ fill: '#ccc' }} 
                axisLine={{ stroke: '#555' }}
              />
              <YAxis 
                domain={['auto', 'auto']}
                tick={{ fill: '#ccc' }} 
                axisLine={{ stroke: '#555' }}
                tickFormatter={(value) => `$${value}`}
              />
              <ChartTooltip 
                content={
                  <ChartTooltipContent 
                    formatter={(value) => [`$${value}`, 'Price']}
                    labelFormatter={(value) => `Time: ${value}`}
                  />
                } 
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="price" 
                name="Gold Price (USD/oz)" 
                stroke="#FFD700" 
                strokeWidth={2} 
                dot={{ r: 2 }} 
                activeDot={{ r: 6 }} 
              />
            </LineChart>
          </ChartContainer>
        );
        
      case 1: // Historical Gold Price Trends
        return (
          <ChartContainer config={chartConfig} className="h-80 w-full">
            <LineChart data={historicalData} margin={{ top: 20, right: 30, left: 20, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#555" />
              <XAxis 
                dataKey="month" 
                tick={{ fill: '#ccc' }} 
                axisLine={{ stroke: '#555' }}
              />
              <YAxis 
                domain={['auto', 'auto']}
                tick={{ fill: '#ccc' }} 
                axisLine={{ stroke: '#555' }}
                tickFormatter={(value) => `$${value}`}
              />
              <ChartTooltip 
                content={
                  <ChartTooltipContent 
                    formatter={(value) => [`$${value}`, 'Price']}
                    labelFormatter={(value) => `${value}`}
                  />
                } 
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="price" 
                name="Gold Price (USD/oz)" 
                stroke="#FFD700" 
                strokeWidth={2} 
                dot={{ r: 2 }} 
              />
            </LineChart>
          </ChartContainer>
        );
        
      case 2: // Gold to Currency Ratio Charts
        return (
          <ChartContainer config={chartConfig} className="h-80 w-full">
            <LineChart data={currencyData} margin={{ top: 20, right: 30, left: 20, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#555" />
              <XAxis 
                dataKey="currency" 
                tick={{ fill: '#ccc' }} 
                axisLine={{ stroke: '#555' }}
              />
              <YAxis 
                domain={['auto', 'auto']}
                tick={{ fill: '#ccc' }} 
                axisLine={{ stroke: '#555' }}
              />
              <ChartTooltip 
                content={
                  <ChartTooltipContent 
                    formatter={(value, name, item) => {
                      return [`${item.payload.price}`, `Price in ${item.payload.currency}`]
                    }}
                  />
                } 
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="price" 
                name="Gold Price per Troy Ounce" 
                stroke="#FFD700" 
                strokeWidth={2} 
                dot={{ r: 4 }} 
              />
            </LineChart>
          </ChartContainer>
        );
        
      case 3: // Gold vs Other Commodities
        const goldData = commoditiesData.find(c => c.name === "Gold").data;
        const colors = {
          Gold: "#FFD700",
          Silver: "#C0C0C0",
          Platinum: "#E5E4E2", 
          Palladium: "#CBA135",
          "Oil (barrel)": "#000000"
        };
        
        return (
          <ChartContainer config={chartConfig} className="h-80 w-full">
            <LineChart data={goldData} margin={{ top: 20, right: 30, left: 20, bottom: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#555" />
              <XAxis 
                dataKey="month" 
                tick={{ fill: '#ccc' }} 
                axisLine={{ stroke: '#555' }}
              />
              <YAxis 
                domain={['auto', 'auto']}
                tick={{ fill: '#ccc' }} 
                axisLine={{ stroke: '#555' }}
                tickFormatter={(value) => `$${value}`}
              />
              <ChartTooltip 
                content={
                  <ChartTooltipContent 
                    formatter={(value) => [`$${value}`, 'Price']}
                    labelFormatter={(value) => `${value}`}
                  />
                } 
              />
              <Legend />
              {commoditiesData.map((commodity) => (
                <Line 
                  key={commodity.name}
                  type="monotone" 
                  data={commodity.data}
                  dataKey="price" 
                  name={commodity.name} 
                  stroke={colors[commodity.name]} 
                  strokeWidth={commodity.name === "Gold" ? 2 : 1.5} 
                  dot={{ r: commodity.name === "Gold" ? 3 : 2 }} 
                />
              ))}
            </LineChart>
          </ChartContainer>
        );
        
      default:
        return (
          <div className="h-80 w-full bg-navy-light/30 rounded-lg flex items-center justify-center">
            <p className="text-gray-400">Select a chart type to view data</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-navy text-white">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gold mb-4">Gold Price Charts</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Access our comprehensive suite of gold price charts and analytical tools for informed investment decisions.
          </p>
        </div>
        
        {chartTypes.map((chart, index) => (
          <div key={index} className="glass-card mb-10 overflow-hidden">
            <div className="p-6 border-b border-gold/20">
              <div className="flex items-center gap-4">
                <ChartBar className="h-8 w-8 text-gold" />
                <h2 className="text-2xl font-bold text-gold">{chart.title}</h2>
              </div>
              <p className="mt-2 text-gray-300">{chart.description}</p>
            </div>
            
            <div className="bg-navy-dark/50 p-4">
              <div className="flex flex-wrap gap-2 mb-4">
                {chart.timeframes.map((time, timeIndex) => (
                  <button 
                    key={timeIndex} 
                    className={`px-4 py-1 rounded-full text-sm font-medium 
                      ${index === activeChartIndex && time === activeTimeframe 
                        ? 'bg-gold text-navy-dark' 
                        : 'bg-navy-light text-gray-300 hover:bg-gold/20'}`}
                    onClick={() => handleTimeframeChange(index, time)}
                  >
                    {time}
                  </button>
                ))}
              </div>
              
              <div className="mb-6">
                {index === activeChartIndex && renderChartContent(index)}
              </div>
              
              <div className="mt-4 flex justify-end">
                <button 
                  className="btn-gold text-sm flex items-center"
                  onClick={() => handleDownloadData(index)}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download Data
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Footer />
    </div>
  );
};

export default GoldPriceChartsPage;
