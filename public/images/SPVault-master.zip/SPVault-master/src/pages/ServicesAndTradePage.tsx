import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

interface Service {
  id: number;
  title: string;
  description: string;
  features: string[];
  icon: React.ReactNode;
}

const services: Service[] = [
  {
    id: 1,
    title: 'Trading Platform',
    description: 'Access our advanced trading platform for real-time precious metals trading with competitive pricing and instant execution.',
    features: [
      'Real-time market data and pricing',
      'Advanced charting tools',
      'Secure order execution',
      'Portfolio tracking',
      'Mobile trading support'
    ],
    icon: (
      <svg className="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
      </svg>
    )
  },
  {
    id: 2,
    title: 'Investment Advisory',
    description: 'Get expert guidance on precious metals investment strategies tailored to your financial goals and risk tolerance.',
    features: [
      'Personalized investment strategies',
      'Market analysis and insights',
      'Risk management guidance',
      'Portfolio diversification',
      'Regular performance reviews'
    ],
    icon: (
      <svg className="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    )
  },
  {
    id: 3,
    title: 'Secure Storage',
    description: 'Store your precious metals in our state-of-the-art, fully insured storage facilities with 24/7 security monitoring.',
    features: [
      'High-security vault facilities',
      'Full insurance coverage',
      '24/7 security monitoring',
      'Regular audits and reports',
      'Easy withdrawal process'
    ],
    icon: (
      <svg className="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
      </svg>
    )
  },
  {
    id: 4,
    title: 'Wealth Management',
    description: 'Comprehensive wealth management services for high-net-worth individuals and institutional clients.',
    features: [
      'Customized investment portfolios',
      'Estate planning assistance',
      'Tax optimization strategies',
      'Legacy planning',
      'Regular portfolio rebalancing'
    ],
    icon: (
      <svg className="w-6 h-6 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    )
  }
];

const ServicesAndTradePage = () => {
  return (
    <div className="min-h-screen bg-navy-dark text-white">
      <Navbar />
      {/* Hero Section */}
      <div className="relative h-[40vh] bg-navy-light flex items-center justify-center">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-navy-dark"></div>
        <div className="relative z-10 text-center">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-gold mb-4">Services & Trade</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Discover our comprehensive range of services and advanced trading platform
          </p>
        </div>
      </div>

      {/* Services Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-playfair font-bold text-gold mb-6">Our Services</h2>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            We offer a comprehensive suite of services designed to meet your precious metals investment needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {services.map((service) => (
            <div key={service.id} className="bg-navy-light p-8 rounded-lg border border-gold/20">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center">
                    {service.icon}
                  </div>
                </div>
                <div className="ml-6">
                  <h3 className="text-xl font-playfair font-bold text-gold mb-4">{service.title}</h3>
                  <p className="text-gray-400 mb-6">{service.description}</p>
                  <ul className="space-y-3">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm text-gray-300">
                        <svg className="w-4 h-4 mr-2 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trading Platform Section */}
        <div className="bg-navy-light rounded-lg border border-gold/20 overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 lg:p-12">
              <h2 className="text-3xl font-playfair font-bold text-gold mb-6">Advanced Trading Platform</h2>
              <p className="text-gray-300 mb-8">
                Experience our state-of-the-art trading platform designed for both beginners and experienced traders. 
                Access real-time market data, execute trades instantly, and manage your portfolio with ease.
              </p>
              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <svg className="w-5 h-5 text-gold mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-300">Real-time market data and pricing</span>
                </div>
                <div className="flex items-center">
                  <svg className="w-5 h-5 text-gold mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-300">Advanced charting and analysis tools</span>
                </div>
                <div className="flex items-center">
                  <svg className="w-5 h-5 text-gold mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-300">Secure and instant trade execution</span>
                </div>
                <div className="flex items-center">
                  <svg className="w-5 h-5 text-gold mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-gray-300">Mobile trading support</span>
                </div>
              </div>
              <button className="bg-gold text-navy-dark font-bold py-3 px-8 rounded-md hover:bg-gold/90 transition-colors duration-300">
                Access Trading Platform
              </button>
            </div>
            <div className="bg-navy-dark p-8 lg:p-12 flex items-center justify-center">
              <div className="relative w-full h-[400px] bg-navy-light rounded-lg border border-gold/20">
                <img 
                    src="https://i.pinimg.com/736x/43/fb/31/43fb31455d675534ba8a42219e25fd32.jpg" 
                    alt="Trading Platform Screenshot" 
                    className="w-full h-auto rounded-lg shadow-lg"
                />

                <div className="absolute inset-0 flex items-center justify-center text-gray-400">
                  Trading Platform Interface
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ServicesAndTradePage; 