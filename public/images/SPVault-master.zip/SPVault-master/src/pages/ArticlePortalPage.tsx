const featuredArticle = {
  id: "featured",
  title: "The Evolution of Gold Trading in the Digital Age",
  description: "How technology is transforming the way we trade and invest in gold, from blockchain to digital gold tokens.",
  excerpt: "How technology is transforming the way we trade and invest in gold...",
  date: "May 22, 2025",
  readTime: "12 min",
  author: "Michael Chen",
  authorTitle: "Digital Assets Analyst",
  category: "Technology",
  imageUrl: "https://i.pinimg.com/736x/20/31/3c/20313ca6492e9b2df38b93911d7e23fb.jpg"
};

const articles = [
  {
    id: "1",
    title: "Understanding Gold Market Dynamics",
    description: "A deep dive into the factors that influence gold prices and market trends.",
    excerpt: "A deep dive into the factors that influence gold prices...",
    date: "May 21, 2025",
    readTime: "8 min",
    author: "Emma Thompson",
    authorTitle: "Market Analyst",
    category: "Market Analysis",
    imageUrl: "https://i.pinimg.com/736x/27/04/ad/2704ad7ae65acda9708ca6e8c6731703.jpg"
  },
  {
    id: "2",
    title: "The Role of Gold in Portfolio Diversification",
    description: "Why gold remains a crucial component of a well-balanced investment portfolio.",
    excerpt: "Why gold remains a crucial component of a well-balanced investment portfolio...",
    date: "May 20, 2025",
    readTime: "10 min",
    author: "Robert Wilson",
    authorTitle: "Investment Advisor",
    category: "Investment Strategy",
    imageUrl: "https://i.pinimg.com/736x/2f/c5/7b/2fc57be0b8f040057648e888b90ed8ed.jpg"
  }
]; 