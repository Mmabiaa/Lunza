import React from 'react';

const ServicesPage = () => {
  const services = [
    {
      id: 'investment-advisory',
      title: 'Investment Advisory',
      description: 'Expert guidance on precious metals investment strategies tailored to your goals.',
      features: [
        'Personalized investment plans',
        'Market analysis and insights',
        'Risk assessment',
        'Portfolio diversification strategies'
      ],
      icon: (
        <svg className="w-8 h-8 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
        </svg>
      )
    },
    {
      id: 'secure-storage',
      title: 'Secure Storage Solutions',
      description: 'State-of-the-art storage facilities for your precious metals investments.',
      features: [
        'Allocated storage options',
        '24/7 security monitoring',
        'Insurance coverage',
        'Regular audits and reporting'
      ],
      icon: (
        <svg className="w-8 h-8 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
        </svg>
      )
    },
    {
      id: 'trading-platform',
      title: 'Trading Platform',
      description: 'Advanced trading platform for seamless precious metals transactions.',
      features: [
        'Real-time market data',
        'Instant order execution',
        'Portfolio tracking',
        'Mobile trading access'
      ],
      icon: (
        <svg className="w-8 h-8 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
        </svg>
      )
    },
    {
      id: 'wealth-management',
      title: 'Wealth Management',
      description: 'Comprehensive wealth management services for precious metals investors.',
      features: [
        'Estate planning',
        'Tax optimization',
        'Succession planning',
        'Regular portfolio reviews'
      ],
      icon: (
        <svg className="w-8 h-8 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      )
    }
  ];

  return (
    <div className="min-h-screen bg-navy-dark">
      {/* Hero Section */}
      <div className="relative bg-navy-dark py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-playfair font-bold text-gold mb-4">
              Our Services
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Comprehensive solutions for your precious metals investment needs,
              backed by expertise and cutting-edge technology.
            </p>
          </div>
        </div>
      </div>

      {/* Services Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service) => (
            <div
              key={service.id}
              className="bg-navy-light rounded-lg p-8 transform transition duration-500 hover:scale-105"
            >
              <div className="bg-gold/10 rounded-full w-16 h-16 flex items-center justify-center mb-6">
                {service.icon}
              </div>
              <h3 className="text-2xl font-playfair font-bold text-gold mb-4">
                {service.title}
              </h3>
              <p className="text-gray-300 mb-6">
                {service.description}
              </p>
              <ul className="space-y-3">
                {service.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-gray-400">
                    <svg
                      className="h-5 w-5 text-gold mr-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                    {feature}
                  </li>
                ))}
              </ul>
              <button className="mt-8 w-full bg-gold text-navy-dark font-semibold py-2 px-4 rounded hover:bg-gold/90 transition-colors">
                Learn More
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-navy-light py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-playfair font-bold text-gold mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Contact our team of experts to discuss how we can help you achieve your investment goals.
          </p>
          <button className="bg-gold text-navy-dark font-semibold py-3 px-8 rounded-lg hover:bg-gold/90 transition-colors">
            Contact Us
          </button>
        </div>
      </div>
    </div>
  );
};

export default ServicesPage; 