import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const TermsOfServicePage = () => {
  const lastUpdated = "May 1, 2025";

  return (
    <div className="min-h-screen bg-navy text-white">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-10">
          <h1 className="text-4xl font-bold text-gold mb-2">Terms of Service</h1>
          <p className="text-gray-400">Last Updated: {lastUpdated}</p>
        </div>
        
        <div className="prose prose-lg prose-invert prose-gold max-w-none">
          <p>
            Welcome to SP VAULT. By accessing our website at www.spvault.com, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this site.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">1. Use License</h2>
          <p>
            Permission is granted to temporarily download one copy of the materials on SP VAULT's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Modify or copy the materials</li>
            <li>Use the materials for any commercial purpose or for any public display</li>
            <li>Attempt to reverse engineer any software contained on SP VAULT's website</li>
            <li>Remove any copyright or other proprietary notations from the materials</li>
            <li>Transfer the materials to another person or "mirror" the materials on any other server</li>
          </ul>
          <p className="mt-4">
            This license shall automatically terminate if you violate any of these restrictions and may be terminated by SP VAULT at any time. Upon terminating your viewing of these materials or upon the termination of this license, you must destroy any downloaded materials in your possession whether in electronic or printed format.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">2. Product Information and Pricing</h2>
          <p>
            SP VAULT strives to ensure that all product information and pricing on our website is accurate. However, we do not warrant that product descriptions or other content is accurate, complete, reliable, current, or error-free. Prices for products are subject to change without notice due to the volatile nature of precious metals markets.
          </p>
          <p className="mt-4">
            All gold and precious metal products are priced based on the current spot price plus a premium. The spot price is updated frequently throughout trading hours. The final price of your purchase will be confirmed at checkout.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">3. Orders and Payments</h2>
          <p>
            When you place an order through our website, you agree to provide current, complete, and accurate purchase and account information. Your submission of an order represents an offer to purchase the products you have selected. SP VAULT reserves the right to refuse or cancel any order for any reason, including pricing errors, unauthorized use of discount codes, or suspected fraudulent activity.
          </p>
          <p className="mt-4">
            Payment must be received in full before any products are shipped or services are provided. We accept various payment methods as specified on our website. For certain high-value transactions, we may require additional verification or specific payment methods.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">4. Shipping and Delivery</h2>
          <p>
            All products are shipped fully insured. Delivery timeframes are estimates only and are not guaranteed. SP VAULT is not responsible for shipping delays caused by customs clearance procedures, weather conditions, or other circumstances beyond our control.
          </p>
          <p className="mt-4">
            Risk of loss and title for products pass to you upon delivery to the carrier. It is your responsibility to provide accurate shipping information and to ensure that someone is available to receive the delivery.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">5. Returns and Refunds</h2>
          <p>
            Due to the nature of precious metals and their price volatility, all sales are final unless the product received is damaged, defective, or not as described. You must inspect your order promptly upon receipt and notify us within 3 business days of any issues.
          </p>
          <p className="mt-4">
            If a return is authorized, you must return the product in its original packaging and condition. Refunds will be issued using the original payment method once the returned product has been received and inspected.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">6. Account Security</h2>
          <p>
            If you create an account on our website, you are responsible for maintaining the confidentiality of your account information, including your password, and for restricting access to your computer. You agree to accept responsibility for all activities that occur under your account.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">7. Disclaimer</h2>
          <p>
            The materials on SP VAULT's website are provided on an 'as is' basis. SP VAULT makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.
          </p>
          <p className="mt-4">
            Further, SP VAULT does not warrant or make any representations concerning the accuracy, likely results, or reliability of the use of the materials on its website or otherwise relating to such materials or on any sites linked to this site.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">8. Limitations</h2>
          <p>
            In no event shall SP VAULT or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on SP VAULT's website, even if SP VAULT or a SP VAULT authorized representative has been notified orally or in writing of the possibility of such damage.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">9. Governing Law</h2>
          <p>
            These Terms of Service shall be governed by and construed in accordance with the laws of the United States, without regard to its conflict of law provisions. Any legal action or proceeding relating to your access to or use of the website shall be instituted in a state or federal court in New York, and you agree to submit to the personal jurisdiction of such courts.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">10. Changes to Terms</h2>
          <p>
            SP VAULT reserves the right to revise these Terms of Service at any time without notice. By using this website, you are agreeing to be bound by the then current version of these Terms of Service.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">11. Contact Information</h2>
          <p>
            If you have any questions about these Terms of Service, please contact us at:
          </p>
          <div className="mt-2">
            <p>Email: legal@spvault.com</p>
            <p>Phone: +44 7441922094</p>
            <p>Address: UK Office, London, United Kingdom</p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default TermsOfServicePage;
