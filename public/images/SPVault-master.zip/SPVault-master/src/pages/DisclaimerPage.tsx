import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const DisclaimerPage = () => {
  const lastUpdated = "May 1, 2025";

  return (
    <div className="min-h-screen bg-navy text-white">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-10">
          <h1 className="text-4xl font-bold text-gold mb-2">Disclaimer</h1>
          <p className="text-gray-400">Last Updated: {lastUpdated}</p>
        </div>
        
        <div className="prose prose-lg prose-invert prose-gold max-w-none">
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Investment Disclaimer</h2>
          <p>
            The information provided on this website is for general informational purposes only and should not be considered as investment advice or a recommendation to buy, sell, or hold any investment or financial product. Investing in gold and precious metals involves risk, and past performance is not indicative of future results.
          </p>
          <p className="mt-4">
            The value of gold and precious metals can be volatile and can significantly decrease or increase based on various factors including economic conditions, market events, and geopolitical risks. Investors should carefully consider their investment objectives, level of experience, and risk appetite before making any investment decisions.
          </p>
          <p className="mt-4">
            SP VAULT strongly recommends that you seek independent financial advice from a qualified professional before making any investment decisions. SP VAULT shall not be liable for any losses, damages, or injuries that may result from any investment decision made on the basis of any information provided on this website.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Content Disclaimer</h2>
          <p>
            All content on this website is provided "as is" without warranty of any kind, either express or implied, including but not limited to the implied warranties of merchantability, fitness for a particular purpose, or non-infringement.
          </p>
          <p className="mt-4">
            SP VAULT makes every effort to ensure that the information on this website is accurate and up-to-date, but we make no representations or warranties about the completeness, reliability, accuracy, suitability, or availability of the website or the information, products, services, or related graphics contained on the website for any purpose.
          </p>
          <p className="mt-4">
            The information contained in market reports, blog posts, articles, and other content on this website is derived from sources believed to be reliable, but SP VAULT does not warrant or guarantee the timeliness, accuracy, or completeness of this information. The information may contain technical inaccuracies or typographical errors, and SP VAULT reserves the right to correct any errors, inaccuracies, or omissions and to change or update information at any time without prior notice.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Forward-Looking Statements</h2>
          <p>
            This website may contain certain forward-looking statements and information relating to SP VAULT that are based on the beliefs of SP VAULT management as well as assumptions made by and information currently available to SP VAULT management.
          </p>
          <p className="mt-4">
            Such statements reflect the current views of SP VAULT with respect to future events and are subject to certain risks, uncertainties, and assumptions. Should one or more of these risks or uncertainties materialize, or should underlying assumptions prove incorrect, actual results may vary materially from those described herein as anticipated, believed, estimated, expected, or intended.
          </p>
          <p className="mt-4">
            SP VAULT does not intend to update these forward-looking statements continually.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Third-Party Links</h2>
          <p>
            This website may contain links to third-party websites or services that are not owned or controlled by SP VAULT. SP VAULT has no control over, and assumes no responsibility for, the content, privacy policies, or practices of any third-party websites or services.
          </p>
          <p className="mt-4">
            You acknowledge and agree that SP VAULT shall not be responsible or liable, directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection with the use of or reliance on any such content, goods, or services available on or through any such websites or services.
          </p>
          <p className="mt-4">
            We strongly advise you to read the terms and conditions and privacy policies of any third-party websites or services that you visit.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Price Information</h2>
          <p>
            All prices displayed on this website for gold and precious metals products are based on the current spot price plus a premium. The spot price is updated frequently throughout trading hours, but there may be a delay in updates during volatile market conditions.
          </p>
          <p className="mt-4">
            The final price of your purchase will be confirmed at checkout. SP VAULT reserves the right to refuse or cancel any order if the spot price has significantly changed between the time of order placement and processing.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Limitation of Liability</h2>
          <p>
            In no event shall SP VAULT, its officers, directors, employees, agents, suppliers, or affiliates be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from:
          </p>
          <ul className="list-disc pl-6 space-y-2">
            <li>Your access to or use of or inability to access or use the website</li>
            <li>Any conduct or content of any third party on the website</li>
            <li>Any content obtained from the website</li>
            <li>Unauthorized access, use, or alteration of your transmissions or content</li>
          </ul>
          <p className="mt-4">
            Whether based on warranty, contract, tort (including negligence), or any other legal theory, whether or not we have been informed of the possibility of such damage, and even if a remedy set forth herein is found to have failed of its essential purpose.
          </p>
          
          <h2 className="text-gold text-2xl font-bold mt-8 mb-4">Contact Us</h2>
          <p>
            If you have any questions about this Disclaimer, please contact us at:
          </p>
          <div className="mt-2">
            <p>Email: legal@spvault.com</p>
            <p>Phone: +44 7441922094</p>
            <p>Address: UK Office, London, United Kingdom</p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default DisclaimerPage;
