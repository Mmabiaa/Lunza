
import React from 'react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import GoldPriceTicker from '../components/GoldPriceTicker';
import ProductShowcase from '../components/ProductShowcase';
import AboutSection from '../components/AboutSection';
import ServicesSection from '../components/ServicesSection';
import ContactSection from '../components/ContactSection';
import Footer from '../components/Footer';

const Index = () => {
  return (
    <div className="min-h-screen bg-navy text-white">
      <Navbar />
      <Hero />
      <GoldPriceTicker />
      <ProductShowcase />
      <AboutSection />
      <ServicesSection />
      <ContactSection />
      <Footer />
    </div>
  );
};

export default Index;
