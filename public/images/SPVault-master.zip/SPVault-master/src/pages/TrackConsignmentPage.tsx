import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const TrackConsignmentPage = () => {
  const [trackingNumber, setTrackingNumber] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleTrackConsignment = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!trackingNumber.trim()) {
      setError('Please enter a tracking number');
      return;
    }

    // For demo purposes, we'll use a hardcoded tracking number
    if (trackingNumber === 'LM498039123SPV') {
      navigate(`/track-consignment/result/${trackingNumber}`);
    } else {
      setError('Invalid tracking number');
    }
  };

  return (
    <div className="min-h-screen bg-navy-dark text-white">
      <Navbar />
      
      {/* Hero Section */}
      <div className="relative h-[40vh] bg-navy-light flex items-center justify-center">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-navy-dark"></div>
        <div className="relative z-10 text-center">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-gold mb-4">Track Consignment</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Enter your tracking number to view your consignment details
          </p>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-navy-light rounded-lg p-8 border border-gold/20">
          <form onSubmit={handleTrackConsignment} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Tracking Number
              </label>
              <input
                type="text"
                value={trackingNumber}
                onChange={(e) => {
                  setTrackingNumber(e.target.value);
                  setError('');
                }}
                placeholder="Enter your tracking number"
                className="w-full bg-navy-dark text-white border border-gold/20 rounded-md px-4 py-3 focus:outline-none focus:ring-2 focus:ring-gold"
              />
              {error && (
                <p className="mt-2 text-sm text-red-400">{error}</p>
              )}
            </div>
            <button
              type="submit"
              className="w-full bg-gold text-navy-dark font-bold py-3 rounded-md hover:bg-gold/90 transition-colors duration-300"
            >
              Track Consignment
            </button>
          </form>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default TrackConsignmentPage; 