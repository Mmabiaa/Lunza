import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

interface Consignment {
  id: string;
  productName: string;
  quantity: number;
  status: 'PENDING' | 'IN_TRANSIT' | 'DELIVERED' | 'CANCELLED';
  trackingNumber: string;
  estimatedDelivery: string;
  currentLocation: string;
  lastUpdate: string;
  value: number;
}

const ConsignmentTrackingPage = () => {
  const [trackingNumber, setTrackingNumber] = useState('');
  const [consignments, setConsignments] = useState<Consignment[]>([
    {
      id: 'CON001',
      productName: 'Gold Investment Bar',
      quantity: 2,
      status: 'IN_TRANSIT',
      trackingNumber: 'LM498039123SPV',
      estimatedDelivery: '2024-03-20',
      currentLocation: 'London Distribution Center',
      lastUpdate: '2024-03-15 14:30:00',
      value: 3900.00
    },
    {
      id: 'CON002',
      productName: 'Gold Sovereign Coin',
      quantity: 5,
      status: 'DELIVERED',
      trackingNumber: 'SPV987654321',
      estimatedDelivery: '2024-03-14',
      currentLocation: 'Delivered to Customer',
      lastUpdate: '2024-03-14 15:45:00',
      value: 2600.00
    },
    {
      id: 'CON003',
      productName: 'Premium Gold Bullion',
      quantity: 1,
      status: 'PENDING',
      trackingNumber: 'SPV456789123',
      estimatedDelivery: '2024-03-22',
      currentLocation: 'Processing Center',
      lastUpdate: '2024-03-15 09:15:00',
      value: 9750.00
    }
  ]);

  const handleTrackConsignment = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, this would make an API call to fetch consignment details
    console.log('Tracking consignment:', trackingNumber);
  };

  const getStatusColor = (status: Consignment['status']) => {
    switch (status) {
      case 'PENDING':
        return 'bg-yellow-400/20 text-yellow-400';
      case 'IN_TRANSIT':
        return 'bg-blue-400/20 text-blue-400';
      case 'DELIVERED':
        return 'bg-green-400/20 text-green-400';
      case 'CANCELLED':
        return 'bg-red-400/20 text-red-400';
      default:
        return 'bg-gray-400/20 text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-navy-dark text-white">
      <Navbar />
      
      {/* Hero Section */}
      <div className="relative h-[40vh] bg-navy-light flex items-center justify-center">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-navy-dark"></div>
        <div className="relative z-10 text-center">
          <h1 className="text-4xl md:text-5xl font-playfair font-bold text-gold mb-4">Consignment Tracking</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Track your precious metals consignments in real-time with our secure tracking system
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Tracking Form */}
          <div className="lg:col-span-1">
            <div className="bg-navy-light rounded-lg p-6 border border-gold/20 sticky top-8">
              <h2 className="text-2xl font-playfair font-bold text-gold mb-6">Track Consignment</h2>
              <form onSubmit={handleTrackConsignment} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    Tracking Number
                  </label>
                  <input
                    type="text"
                    value={trackingNumber}
                    onChange={(e) => setTrackingNumber(e.target.value)}
                    placeholder="Enter tracking number"
                    className="w-full bg-navy-dark text-white border border-gold/20 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-gold"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-gold text-navy-dark font-bold py-3 rounded-md hover:bg-gold/90 transition-colors duration-300"
                >
                  Track Consignment
                </button>
              </form>
            </div>
          </div>

          {/* Consignment List */}
          <div className="lg:col-span-2">
            <div className="bg-navy-light rounded-lg p-6 border border-gold/20">
              <h2 className="text-2xl font-playfair font-bold text-gold mb-6">Your Consignments</h2>
              <div className="space-y-6">
                {consignments.map((consignment) => (
                  <div key={consignment.id} className="bg-navy-dark rounded-lg p-6 border border-gold/20">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-gold mb-2">{consignment.productName}</h3>
                        <p className="text-gray-400">Tracking Number: {consignment.trackingNumber}</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-sm ${getStatusColor(consignment.status)}`}>
                        {consignment.status.replace('_', ' ')}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <p className="text-gray-400 text-sm">Quantity</p>
                        <p className="text-white">{consignment.quantity}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Value</p>
                        <p className="text-gold">${consignment.value.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Estimated Delivery</p>
                        <p className="text-white">{consignment.estimatedDelivery}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Current Location</p>
                        <p className="text-white">{consignment.currentLocation}</p>
                      </div>
                    </div>
                    <div className="text-sm text-gray-400">
                      Last Update: {consignment.lastUpdate}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ConsignmentTrackingPage; 