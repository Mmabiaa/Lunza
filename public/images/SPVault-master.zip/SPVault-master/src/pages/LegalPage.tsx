
import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { FileText } from 'lucide-react';

const LegalPage = () => {
  const legalDocuments = [
    {
      title: "Privacy Policy",
      description: "Learn about how we collect, use, and protect your personal information when you use our services.",
      path: "/privacy-policy",
      icon: <FileText className="h-10 w-10 text-gold" />
    },
    {
      title: "Terms of Service",
      description: "Our terms and conditions for using GoldElite's services, website, and platform.",
      path: "/terms-of-service",
      icon: <FileText className="h-10 w-10 text-gold" />
    },
    {
      title: "Cookie Policy",
      description: "Information about how we use cookies and similar technologies on our website.",
      path: "/cookie-policy",
      icon: <FileText className="h-10 w-10 text-gold" />
    },
    {
      title: "Disclaimer",
      description: "Important disclaimers regarding investment advice, market predictions, and the use of our services.",
      path: "/disclaimer",
      icon: <FileText className="h-10 w-10 text-gold" />
    }
  ];

  return (
    <div className="min-h-screen bg-navy text-white">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-gold mb-4">Legal Documents</h1>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Access our legal documentation and policies that govern the use of our services and protect your rights.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {legalDocuments.map((document, index) => (
            <a 
              href={document.path} 
              key={index}
              className="glass-card hover:border-gold hover:shadow-lg hover:shadow-gold/10 transition-all duration-300"
            >
              <div className="flex flex-col items-center text-center p-6">
                <div className="mb-4">
                  {document.icon}
                </div>
                <h3 className="text-xl font-bold text-gold mb-2">{document.title}</h3>
                <p className="text-gray-400">{document.description}</p>
              </div>
            </a>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default LegalPage;
