import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import WhatsAppFloatingButton from "./components/WhatsAppFloatingButton";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import ResourcesPage from "./pages/ResourcesPage";
import GoldPriceChartsPage from "./pages/GoldPriceChartsPage";
import InvestmentGuidesPage from "./pages/InvestmentGuidesPage";
import InvestmentGuidePage from "./pages/InvestmentGuidePage";
import MarketNewsPage from "./pages/MarketNewsPage";
import FAQsPage from "./pages/FAQsPage";
import BlogPage from "./pages/BlogPage";
import BlogPostPage from "./pages/BlogPostPage";
import LegalPage from "./pages/LegalPage";
import PrivacyPolicyPage from "./pages/PrivacyPolicyPage";
import TermsOfServicePage from "./pages/TermsOfServicePage";
import CookiePolicyPage from "./pages/CookiePolicyPage";
import DisclaimerPage from "./pages/DisclaimerPage";
import AllProductsPage from "./pages/AllProductsPage";
import AllProductsDetailsPage from "./pages/AllProductsDetailsPage";
import ServicesAndTradePage from "./pages/ServicesAndTradePage";
import ContactPage from "./pages/ContactPage";
import ProductDetailsPage from "./pages/ProductDetailsPage";
import TradeNowPage from "./pages/TradeNowPage";
import ConsignmentTrackingPage from "./pages/ConsignmentTrackingPage";
import TrackConsignmentPage from "./pages/TrackConsignmentPage";
import TrackConsignmentResultPage from "./pages/TrackConsignmentResultPage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <WhatsAppFloatingButton />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/all-products" element={<AllProductsPage />} />
          <Route path="/product/:id" element={<ProductDetailsPage />} />
          <Route path="/all-products/:id" element={<AllProductsDetailsPage />} />
          <Route path="/services-and-trade" element={<ServicesAndTradePage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/resources" element={<ResourcesPage />} />
          <Route path="/gold-price-charts" element={<GoldPriceChartsPage />} />
          <Route path="/investment-guides" element={<InvestmentGuidesPage />} />
          <Route path="/market-news" element={<MarketNewsPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/blog/:id" element={<BlogPostPage />} />
          <Route path="/faqs" element={<FAQsPage />} />
          <Route path="/track-consignment" element={<TrackConsignmentPage />} />
          <Route path="/track-consignment/result/:trackingNumber" element={<TrackConsignmentResultPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
