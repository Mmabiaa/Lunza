import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useNavigate } from 'react-router-dom';

type Product = {
  id: number;
  name: string;
  description: string;
  price: string;
  image: string;
  purity: string;
  weight: string;
};

const ProductShowcase = () => {
  const navigate = useNavigate();
  const [products] = useState<Product[]>([
    {
      id: 1,
      name: "Gold Investment Bar",
      description: "Our flagship 999.9 fine gold bar, perfect for long-term investment.",
      price: "$1,950 per oz",
      image: "https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&q=80&w=2070",
      purity: "99.99%",
      weight: "1 oz"
    },
    {
      id: 2,
      name: "Gold Sovereign Coin",
      description: "Historic gold coins with excellent liquidity and worldwide recognition.",
      price: "$520 per coin",
      image: "https://images.unsplash.com/photo-1605792657660-596af9009e82?auto=format&fit=crop&q=80&w=2071",
      purity: "22 Karat",
      weight: "7.98g"
    },
    {
      id: 3,
      name: "Premium Gold Bullion",
      description: "High-purity gold bullion bars with tamper-evident packaging.",
      price: "$9,750 per bar",
      image: "https://i.pinimg.com/736x/96/7a/3f/967a3fb9863cb0560db2e52156645a9c.jpg",
      purity: "99.99%",
      weight: "5 oz"
    }
  ]);

  const handleViewDetails = (productId: number) => {
    navigate(`/product/${productId}`);
  };

  return (
    <section id="products" className="section-padding bg-navy">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 text-gold">Premium Gold Products</h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Discover our selection of investment-grade gold products, each meeting the highest standards of purity and craftsmanship.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {products.map((product) => (
            <Card key={product.id} className="glass-card hover:border-gold/50 transition-all duration-300 overflow-hidden group">
              <div className="h-56 overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-gold mb-2">{product.name}</h3>
                <p className="text-gray-300 mb-4">{product.description}</p>
                <div className="flex justify-between text-sm mb-4">
                  <span className="text-gray-400">Purity: <span className="text-white">{product.purity}</span></span>
                  <span className="text-gray-400">Weight: <span className="text-white">{product.weight}</span></span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gold font-semibold">{product.price}</span>
                  <Button 
                    onClick={() => handleViewDetails(product.id)}
                    className="btn-gold"
                  >
                    Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button 
            onClick={() => navigate('/all-products')}
            className="btn-gold"
          >
            View All Products
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ProductShowcase;
