import { useEffect, useState } from 'react';
import productsApi, { Product } from '@/lib/api/products';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Link } from 'react-router-dom';

export default function ProductList() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await productsApi.getAllProducts();
      setProducts(response.data.products);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch products.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div>Loading products...</div>;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {products.map((product) => (
        <Card key={product._id}>
          <CardHeader>
            <CardTitle>{product.name}</CardTitle>
            <CardDescription>{product.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p>Category: {product.category}</p>
              <p>Type: {product.type}</p>
              <p>Weight: {product.weight.value} {product.weight.unit}</p>
              <p>Purity: {product.purity}%</p>
              <p>Price: {product.price.current} {product.price.currency}</p>
              <p>Stock: {product.stock}</p>
            </div>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full">
              <Link to={`/products/${product._id}`}>View Details</Link>
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
} 