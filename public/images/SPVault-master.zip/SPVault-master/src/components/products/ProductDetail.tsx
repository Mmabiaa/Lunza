import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import productsApi, { Product, Review } from '@/lib/api/products';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';

export default function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [review, setReview] = useState({ rating: 5, comment: '' });
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (id) {
      fetchProduct();
    }
  }, [id]);

  const fetchProduct = async () => {
    try {
      const response = await productsApi.getProduct(id!);
      setProduct(response.data.product);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch product details.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({
        title: 'Error',
        description: 'Please login to submit a review.',
        variant: 'destructive',
      });
      return;
    }

    try {
      await productsApi.addReview(id!, review);
      toast({
        title: 'Success',
        description: 'Review submitted successfully.',
      });
      fetchProduct(); // Refresh product data to show new review
      setReview({ rating: 5, comment: '' });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to submit review.',
        variant: 'destructive',
      });
    }
  };

  if (loading) {
    return <div>Loading product details...</div>;
  }

  if (!product) {
    return <div>Product not found</div>;
  }

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>{product.name}</CardTitle>
          <CardDescription>{product.description}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold">Details</h3>
                <p>Category: {product.category}</p>
                <p>Type: {product.type}</p>
                <p>Weight: {product.weight.value} {product.weight.unit}</p>
                <p>Purity: {product.purity}%</p>
                <p>Price: {product.price.current} {product.price.currency}</p>
                <p>Stock: {product.stock}</p>
              </div>
              {product.images && product.images.length > 0 && (
                <div>
                  <h3 className="font-semibold">Images</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {product.images.map((image, index) => (
                      <img
                        key={index}
                        src={image}
                        alt={`${product.name} - Image ${index + 1}`}
                        className="w-full h-48 object-cover rounded-lg"
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div>
              <h3 className="font-semibold mb-4">Reviews</h3>
              {product.reviews && product.reviews.length > 0 ? (
                <div className="space-y-4">
                  {product.reviews.map((review: Review) => (
                    <div key={review._id} className="border p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">Rating: {review.rating}/5</span>
                        <span className="text-sm text-gray-500">
                          {new Date(review.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <p>{review.comment}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p>No reviews yet.</p>
              )}
              {user && (
                <form onSubmit={handleReviewSubmit} className="mt-6 space-y-4">
                  <div>
                    <Label htmlFor="rating">Rating</Label>
                    <Input
                      id="rating"
                      type="number"
                      min="1"
                      max="5"
                      value={review.rating}
                      onChange={(e) => setReview({ ...review, rating: Number(e.target.value) })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="comment">Comment</Label>
                    <Textarea
                      id="comment"
                      value={review.comment}
                      onChange={(e) => setReview({ ...review, comment: e.target.value })}
                      required
                    />
                  </div>
                  <Button type="submit">Submit Review</Button>
                </form>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
} 