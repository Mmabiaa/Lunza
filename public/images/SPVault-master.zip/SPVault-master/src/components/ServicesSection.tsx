import React from 'react';
import { ChartBar, CreditCard, Shield, Globe } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";

const ServicesSection = () => {
  const services = [
    {
      icon: <ChartBar className="h-12 w-12 text-gold" />,
      title: "Investment Advisory",
      description: "Personalized consultation with our gold investment experts to build a strategic precious metals portfolio."
    },
    {
      icon: <CreditCard className="h-12 w-12 text-gold" />,
      title: "Buying & Selling",
      description: "Competitive pricing on all transactions with transparent fee structures and efficient settlement."
    },
    {
      icon: <Shield className="h-12 w-12 text-gold" />,
      title: "Secure Storage",
      description: "Ultra-secure vault facilities with comprehensive insurance coverage and regular auditing."
    },
    {
      icon: <Globe className="h-12 w-12 text-gold" />,
      title: "Global Delivery",
      description: "Insured shipping of gold products to destinations worldwide with discreet packaging."
    }
  ];
  
  return (
    <section id="services" className="section-padding bg-navy">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 text-gold">Our Premium Services</h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            SP VAULT offers comprehensive gold investment services, from expert advisory to secure storage solutions.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="glass-card flex flex-col items-center text-center h-full hover:border-gold/40 transition-colors duration-300">
              <CardContent className="pt-6 px-4 flex flex-col items-center flex-grow">
                <div className="mb-4 p-4 rounded-full bg-navy border border-gold/20">
                  {service.icon}
                </div>
                <h3 className="text-xl font-semibold text-gold mb-3">{service.title}</h3>
                <p className="text-gray-300">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="mt-16 p-8 glass-card border-gold/30">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-gold mb-4">Vault Membership Program</h3>
              <p className="text-gray-300 mb-6">
                Join our exclusive vault membership program for premium benefits including priority access to new products, reduced storage fees, and personalized investment consultations.
              </p>
              <ul className="space-y-2">
                {[
                  "24/7 access to your stored gold",
                  "Quarterly portfolio review sessions",
                  "Invitations to exclusive gold investment events",
                  "Preferential rates on all transactions"
                ].map((benefit, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-gold mr-2">✓</span>
                    <span className="text-gray-300">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="relative h-64 rounded-lg overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1582281171754-405cb2a75fb1?auto=format&fit=crop&q=80&w=2070" 
                alt="Gold Vault" 
                className="absolute inset-0 h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-navy-dark/40 flex items-center justify-center">
                <span className="px-4 py-2 bg-gold text-navy font-bold rounded">
                  Premium Security
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
