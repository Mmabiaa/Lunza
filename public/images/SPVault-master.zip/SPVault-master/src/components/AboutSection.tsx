
import React from 'react';
import { Shield, Check, Award, Lock } from 'lucide-react';

const AboutSection = () => {
  const features = [
    {
      icon: <Shield className="h-12 w-12 text-gold" />,
      title: "Secure Storage",
      description: "State-of-the-art vault facilities with 24/7 security and comprehensive insurance."
    },
    {
      icon: <Check className="h-12 w-12 text-gold" />,
      title: "Verified Authenticity",
      description: "Every product comes with certificates of authenticity and is verified by experts."
    },
    {
      icon: <Award className="h-12 w-12 text-gold" />,
      title: "Industry Expertise",
      description: "Our team brings decades of experience in precious metals and investment strategy."
    },
    {
      icon: <Lock className="h-12 w-12 text-gold" />,
      title: "Privacy Guaranteed",
      description: "Discreet transactions and confidential client relationships are our priority."
    }
  ];

  return (
    <section id="about" className="section-padding bg-navy-dark relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-gold/5 blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full bg-gold/5 blur-3xl"></div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold mb-6 text-gold">About GoldElite</h2>
            <p className="text-gray-300 mb-6">
              For over 25 years, GoldElite has been the trusted partner for investors seeking to diversify their portfolios with physical gold. We combine deep industry expertise with exceptional client service to provide a premium experience.
            </p>
            <p className="text-gray-300 mb-6">
              Our commitment to security, transparency, and excellence has made us the preferred choice for both individual and institutional investors worldwide. Every product in our collection is carefully selected and verified to ensure the highest quality and purity.
            </p>
            <div className="flex items-center space-x-4">
              <img src="https://i.pinimg.com/736x/59/2a/2a/592a2aec92d3f44a24925e6718bdc18c.jpg" alt="CEO" className="w-16 h-16 rounded-full object-cover border border-gold" />
              <div>
                <p className="text-gold font-semibold">Jonathan Gold</p>
                <p className="text-gray-400 text-sm">Founder & CEO</p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <div key={index} className="glass-card flex flex-col items-center text-center hover:border-gold/40 transition-colors duration-300">
                <div className="mb-4">{feature.icon}</div>
                <h3 className="text-lg font-bold text-gold mb-2">{feature.title}</h3>
                <p className="text-gray-300 text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
