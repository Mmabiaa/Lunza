
import React, { useState, useEffect } from 'react';

type GoldPrice = {
  price: string;
  change: string;
  changePercentage: string;
  isPositive: boolean;
};

const GoldPriceTicker = () => {
  // Mock data for demonstration purposes
  const [goldPrices, setGoldPrices] = useState<GoldPrice[]>([
    { price: '$1,925.40', change: '+12.30', changePercentage: '+0.64%', isPositive: true },
    { price: '$1,913.10', change: '-5.20', changePercentage: '-0.27%', isPositive: false },
    { price: '$1,918.30', change: '+8.50', changePercentage: '+0.44%', isPositive: true },
  ]);
  
  // In a real application, you would fetch this data from an API
  useEffect(() => {
    const fetchGoldPrices = () => {
      // This would be an API call in a real application
      const mockUpdate = [
        { price: '$1,925.40', change: '+12.30', changePercentage: '+0.64%', isPositive: true },
        { price: '$1,913.10', change: '-5.20', changePercentage: '-0.27%', isPositive: false },
        { price: '$1,918.30', change: '+8.50', changePercentage: '+0.44%', isPositive: true },
      ];
      setGoldPrices(mockUpdate);
    };
    
    // Update prices every 10 seconds
    const interval = setInterval(fetchGoldPrices, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full bg-navy-dark border-t border-b border-gold/20 py-2 overflow-hidden">
      <div className="flex animate-ticker whitespace-nowrap">
        {[...goldPrices, ...goldPrices, ...goldPrices].map((item, index) => (
          <div 
            key={index} 
            className="flex items-center mx-12"
          >
            <span className="font-semibold text-gold">Gold</span>
            <span className="mx-2 text-white">{item.price}</span>
            <span className={`${item.isPositive ? 'text-green-400' : 'text-red-400'} flex items-center`}>
              {item.change} ({item.changePercentage})
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GoldPriceTicker;
