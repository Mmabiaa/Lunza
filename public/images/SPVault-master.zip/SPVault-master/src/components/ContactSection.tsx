import React from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { MapPin, Phone, Mail, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const ContactSection = () => {
  const navigate = useNavigate();

  const handleBookAppointment = () => {
    navigate('/contact');
  };

  return (
    <section id="contact" className="section-padding bg-navy-dark">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4 text-gold">Contact Us</h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Reach out to our team of gold investment experts for personalized assistance with your precious metals portfolio.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="glass-card">
            <h3 className="text-xl font-semibold text-gold mb-6">Send Us a Message</h3>
            <form className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-gray-300 mb-2">Name</label>
                  <Input id="name" className="bg-navy-light border-gold/20 focus:border-gold" placeholder="Your name" />
                </div>
                <div>
                  <label htmlFor="email" className="block text-gray-300 mb-2">Email</label>
                  <Input id="email" className="bg-navy-light border-gold/20 focus:border-gold" placeholder="Your email" type="email" />
                </div>
              </div>
              <div>
                <label htmlFor="subject" className="block text-gray-300 mb-2">Subject</label>
                <Input id="subject" className="bg-navy-light border-gold/20 focus:border-gold" placeholder="Subject" />
              </div>
              <div>
                <label htmlFor="message" className="block text-gray-300 mb-2">Message</label>
                <Textarea 
                  id="message" 
                  className="bg-navy-light border-gold/20 focus:border-gold min-h-[150px]" 
                  placeholder="Your message" 
                />
              </div>
              <Button className="btn-gold w-full">Send Message</Button>
            </form>
          </div>
          
          <div>
            <div className="glass-card mb-8">
              <h3 className="text-xl font-semibold text-gold mb-6">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <MapPin className="h-6 w-6 text-gold mr-4 mt-0.5" />
                  <div>
                    <p className="text-white">SP VAULT Headquarters</p>
                    <p className="text-gray-400">UK Office</p>
                    <p className="text-gray-400">London, United Kingdom</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <Phone className="h-6 w-6 text-gold mr-4" />
                  <p className="text-white">+44 7441922094</p>
                </div>
                
                <div className="flex items-center">
                  <Mail className="h-6 w-6 text-gold mr-4" />
                  <p className="text-white">sp.vault@mail.com</p>
                </div>
                
                <div className="flex items-start">
                  <Clock className="h-6 w-6 text-gold mr-4 mt-0.5" />
                  <div>
                    <p className="text-white">Business Hours</p>
                    <p className="text-gray-400">Monday-Friday: 9am-6pm GMT</p>
                    <p className="text-gray-400">Saturday: By appointment only</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="glass-card">
              <h3 className="text-xl font-semibold text-gold mb-6">Schedule a Consultation</h3>
              <p className="text-gray-300 mb-4">
                Book a personalized session with our gold investment specialists to discuss your investment goals.
              </p>
              <Button 
                onClick={handleBookAppointment}
                className="btn-gold w-full"
              >
                Book Appointment
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
