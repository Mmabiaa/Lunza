import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-navy-dark/80 backdrop-blur-md border-b border-gold/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link to="/" className="text-gold font-playfair font-bold text-2xl">SP VAULT</Link>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <Link to="/" className="gold-link px-3 py-2">Home</Link>
                
                <NavigationMenu>
                  <NavigationMenuList>
                    <NavigationMenuItem>
                      <NavigationMenuTrigger className="gold-link px-3 py-2 bg-transparent focus:bg-transparent hover:bg-transparent data-[state=open]:bg-transparent">Resources</NavigationMenuTrigger>
                      <NavigationMenuContent className="bg-navy-dark/95 backdrop-blur-md border border-gold/20 rounded-md p-2 w-[400px]">
                        <ul className="grid gap-2 p-2">
                          <li>
                            <Link to="/resources" className="block p-2 hover:bg-gold/10 rounded-md">
                              <span className="text-gold font-medium">All Resources</span>
                              <p className="text-sm text-gray-400">Browse all available resources</p>
                            </Link>
                          </li>
                          <li>
                            <Link to="/gold-price-charts" className="block p-2 hover:bg-gold/10 rounded-md">
                              <span className="text-gold font-medium">Gold Price Charts</span>
                              <p className="text-sm text-gray-400">Interactive price charts and analysis</p>
                            </Link>
                          </li>
                          <li>
                            <Link to="/investment-guides" className="block p-2 hover:bg-gold/10 rounded-md">
                              <span className="text-gold font-medium">Investment Guides</span>
                              <p className="text-sm text-gray-400">Comprehensive investment resources</p>
                            </Link>
                          </li>
                          <li>
                            <Link to="/market-news" className="block p-2 hover:bg-gold/10 rounded-md">
                              <span className="text-gold font-medium">Market News</span>
                              <p className="text-sm text-gray-400">Latest gold market updates</p>
                            </Link>
                          </li>
                          <li>
                            <Link to="/blog" className="block p-2 hover:bg-gold/10 rounded-md">
                              <span className="text-gold font-medium">Blog</span>
                              <p className="text-sm text-gray-400">Articles and insights</p>
                            </Link>
                          </li>
                          <li>
                            <Link to="/faqs" className="block p-2 hover:bg-gold/10 rounded-md">
                              <span className="text-gold font-medium">FAQs</span>
                              <p className="text-sm text-gray-400">Frequently asked questions</p>
                            </Link>
                          </li>
                        </ul>
                      </NavigationMenuContent>
                    </NavigationMenuItem>
                  </NavigationMenuList>
                </NavigationMenu>
                
                <Link to="/all-products" className="gold-link px-3 py-2">Products</Link>
                <Link to="/services-and-trade" className="gold-link px-3 py-2">Services</Link>
                <Link to="/contact" className="gold-link px-3 py-2">Contact</Link>
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <Link to="/track-consignment" className="btn-gold">Track Consignment</Link>
          </div>
          <div className="-mr-2 flex md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              type="button"
              className="bg-navy-light inline-flex items-center justify-center p-2 rounded-md text-gold hover:text-gold-light focus:outline-none"
              aria-controls="mobile-menu"
              aria-expanded="false"
            >
              <span className="sr-only">Open main menu</span>
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden absolute w-full bg-navy-dark/95 backdrop-blur-md" id="mobile-menu">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 flex flex-col">
            <Link to="/" className="gold-link block px-3 py-2" onClick={() => setIsOpen(false)}>Home</Link>
            <Link to="/resources" className="gold-link block px-3 py-2" onClick={() => setIsOpen(false)}>Resources</Link>
            <Link to="/gold-price-charts" className="gold-link block px-3 py-2 pl-6 text-sm" onClick={() => setIsOpen(false)}>- Gold Price Charts</Link>
            <Link to="/investment-guides" className="gold-link block px-3 py-2 pl-6 text-sm" onClick={() => setIsOpen(false)}>- Investment Guides</Link>
            <Link to="/market-news" className="gold-link block px-3 py-2 pl-6 text-sm" onClick={() => setIsOpen(false)}>- Market News</Link>
            <Link to="/faqs" className="gold-link block px-3 py-2 pl-6 text-sm" onClick={() => setIsOpen(false)}>- FAQs</Link>
            <Link to="/blog" className="gold-link block px-3 py-2 pl-6 text-sm" onClick={() => setIsOpen(false)}>- Blog</Link>
            <Link to="/all-products" className="gold-link block px-3 py-2" onClick={() => setIsOpen(false)}>Products</Link>
            <Link to="/services-and-trade" className="gold-link block px-3 py-2" onClick={() => setIsOpen(false)}>Services</Link>
            <Link to="/contact" className="gold-link block px-3 py-2" onClick={() => setIsOpen(false)}>Contact</Link>
            <Link to="/track-consignment" className="btn-gold block text-center mt-4" onClick={() => setIsOpen(false)}>Track Consignment</Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
