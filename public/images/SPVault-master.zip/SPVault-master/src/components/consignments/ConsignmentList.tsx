import { useEffect, useState } from 'react';
import consignmentsApi, { Consignment } from '@/lib/api/consignments';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

export default function ConsignmentList() {
  const [consignments, setConsignments] = useState<Consignment[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    fetchConsignments();
  }, []);

  const fetchConsignments = async () => {
    try {
      const response = await consignmentsApi.getMyConsignments();
      setConsignments(response.data.consignments);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch consignments.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div>Loading consignments...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">My Consignments</h2>
        <Button asChild>
          <Link to="/consignments/new">Create New Consignment</Link>
        </Button>
      </div>
      <div className="grid grid-cols-1 gap-6">
        {consignments.map((consignment) => (
          <Card key={consignment._id}>
            <CardHeader>
              <CardTitle>Consignment #{consignment._id}</CardTitle>
              <CardDescription>
                Type: {consignment.type} | Status: {consignment.status}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold">Items</h3>
                  <ul className="list-disc list-inside">
                    {consignment.items.map((item, index) => (
                      <li key={index}>
                        Quantity: {item.quantity} | Price: {item.price} {consignment.payment.currency}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold">Shipping Address</h3>
                  <p>
                    {consignment.shippingAddress.street}, {consignment.shippingAddress.city}
                  </p>
                  <p>
                    {consignment.shippingAddress.state}, {consignment.shippingAddress.country} {consignment.shippingAddress.zipCode}
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold">Payment</h3>
                  <p>Method: {consignment.payment.method}</p>
                  <p>
                    Amount: {consignment.payment.amount} {consignment.payment.currency}
                  </p>
                </div>
                {consignment.trackingNumber && (
                  <div>
                    <h3 className="font-semibold">Tracking</h3>
                    <p>Number: {consignment.trackingNumber}</p>
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button asChild variant="outline">
                <Link to={`/consignments/${consignment._id}`}>View Details</Link>
              </Button>
              {consignment.trackingNumber && (
                <Button asChild>
                  <Link to={`/consignments/track/${consignment.trackingNumber}`}>Track</Link>
                </Button>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
} 