import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import consignmentsApi, { CreateConsignmentData } from '@/lib/api/consignments';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';

export default function ConsignmentForm() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<CreateConsignmentData>({
    type: 'purchase',
    items: [{ product: '', quantity: 1, price: 0 }],
    shippingAddress: {
      street: '',
      city: '',
      state: '',
      country: '',
      zipCode: '',
    },
    payment: {
      method: 'credit_card',
      amount: 0,
      currency: 'USD',
    },
  });

  const handleItemChange = (index: number, field: string, value: string | number) => {
    const newItems = [...formData.items];
    newItems[index] = { ...newItems[index], [field]: value };
    setFormData({ ...formData, items: newItems });
  };

  const addItem = () => {
    setFormData({
      ...formData,
      items: [...formData.items, { product: '', quantity: 1, price: 0 }],
    });
  };

  const removeItem = (index: number) => {
    const newItems = formData.items.filter((_, i) => i !== index);
    setFormData({ ...formData, items: newItems });
  };

  const handleAddressChange = (field: string, value: string) => {
    setFormData({
      ...formData,
      shippingAddress: { ...formData.shippingAddress, [field]: value },
    });
  };

  const handlePaymentChange = (field: string, value: string | number) => {
    setFormData({
      ...formData,
      payment: { ...formData.payment, [field]: value },
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({
        title: 'Error',
        description: 'Please login to create a consignment.',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    try {
      await consignmentsApi.createConsignment(formData);
      toast({
        title: 'Success',
        description: 'Consignment created successfully.',
      });
      navigate('/consignments');
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create consignment.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="space-y-4">
        <div>
          <Label htmlFor="type">Consignment Type</Label>
          <Select
            value={formData.type}
            onValueChange={(value) => setFormData({ ...formData, type: value as 'purchase' | 'sale' | 'storage' })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="purchase">Purchase</SelectItem>
              <SelectItem value="sale">Sale</SelectItem>
              <SelectItem value="storage">Storage</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Items</h3>
            <Button type="button" onClick={addItem} variant="outline">
              Add Item
            </Button>
          </div>
          {formData.items.map((item, index) => (
            <div key={index} className="grid grid-cols-3 gap-4 p-4 border rounded-lg">
              <div>
                <Label>Product ID</Label>
                <Input
                  value={item.product}
                  onChange={(e) => handleItemChange(index, 'product', e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Quantity</Label>
                <Input
                  type="number"
                  min="1"
                  value={item.quantity}
                  onChange={(e) => handleItemChange(index, 'quantity', Number(e.target.value))}
                  required
                />
              </div>
              <div>
                <Label>Price</Label>
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  value={item.price}
                  onChange={(e) => handleItemChange(index, 'price', Number(e.target.value))}
                  required
                />
              </div>
              {index > 0 && (
                <Button
                  type="button"
                  variant="destructive"
                  onClick={() => removeItem(index)}
                  className="col-span-3"
                >
                  Remove Item
                </Button>
              )}
            </div>
          ))}
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Shipping Address</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="street">Street</Label>
              <Input
                id="street"
                value={formData.shippingAddress.street}
                onChange={(e) => handleAddressChange('street', e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="city">City</Label>
              <Input
                id="city"
                value={formData.shippingAddress.city}
                onChange={(e) => handleAddressChange('city', e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="state">State</Label>
              <Input
                id="state"
                value={formData.shippingAddress.state}
                onChange={(e) => handleAddressChange('state', e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="country">Country</Label>
              <Input
                id="country"
                value={formData.shippingAddress.country}
                onChange={(e) => handleAddressChange('country', e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="zipCode">ZIP Code</Label>
              <Input
                id="zipCode"
                value={formData.shippingAddress.zipCode}
                onChange={(e) => handleAddressChange('zipCode', e.target.value)}
                required
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Payment</h3>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="paymentMethod">Method</Label>
              <Select
                value={formData.payment.method}
                onValueChange={(value) => handlePaymentChange('method', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select method" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="credit_card">Credit Card</SelectItem>
                  <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                  <SelectItem value="paypal">PayPal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                min="0"
                step="0.01"
                value={formData.payment.amount}
                onChange={(e) => handlePaymentChange('amount', Number(e.target.value))}
                required
              />
            </div>
            <div>
              <Label htmlFor="currency">Currency</Label>
              <Select
                value={formData.payment.currency}
                onValueChange={(value) => handlePaymentChange('currency', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? 'Creating...' : 'Create Consignment'}
      </Button>
    </form>
  );
} 