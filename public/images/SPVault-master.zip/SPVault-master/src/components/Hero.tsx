import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { useNavigate } from 'react-router-dom';

const Hero = () => {
  const navigate = useNavigate();

  const handleExploreProducts = () => {
    navigate('/all-products');
  };

  const handleLearnMore = () => {
    navigate('/services-and-trade');
  };

  return (
    <div className="relative min-h-[80vh] flex items-center justify-center overflow-hidden">
      {/* Background with overlay */}
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1610375461246-83df859d849d?auto=format&fit=crop&q=80&w=2070')] bg-cover bg-center">
        <div className="absolute inset-0 bg-navy-dark/80"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="animate-fade-in opacity-0 [animation-delay:0.2s] text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6">
          <span className="bg-clip-text text-transparent bg-gold-gradient">Secure Your Future</span>
          <br />
          <span className="text-white">With Premium Gold</span>
        </h1>
        
        <p className="animate-fade-in opacity-0 [animation-delay:0.4s] text-lg md:text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
          SP VAULT offers premium investment-grade gold products with secure storage solutions, expert guidance, and world-class security to protect your wealth.
        </p>
        
        <div className="animate-fade-in opacity-0 [animation-delay:0.6s] flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={handleExploreProducts}
            className="btn-gold text-lg px-8 py-6"
          >
            Explore Products
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
          <Button 
            onClick={handleLearnMore}
            variant="outline" 
            className="border-gold text-gold hover:bg-gold/10 text-lg px-8 py-6"
          >
            Learn More
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Hero;
