import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import marketNewsApi, { MarketNews } from '@/lib/api/marketNews';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';

export default function MarketNewsList() {
  const [news, setNews] = useState<MarketNews[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    fetchNews();
  }, []);

  const fetchNews = async () => {
    try {
      const response = await marketNewsApi.getAllNews();
      setNews(response.data);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to fetch market news.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Market News</h1>
        {user?.role === 'admin' && (
          <Link to="/market-news/new">
            <Button>Create News</Button>
          </Link>
        )}
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {news.map((item) => (
          <Card key={item._id} className="p-6">
            <h2 className="text-xl font-semibold mb-2">{item.title}</h2>
            <p className="text-gray-600 mb-4">{item.content.substring(0, 150)}...</p>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500">
                {new Date(item.createdAt).toLocaleDateString()}
              </span>
              <Link to={`/market-news/${item._id}`}>
                <Button variant="outline">Read More</Button>
              </Link>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
} 