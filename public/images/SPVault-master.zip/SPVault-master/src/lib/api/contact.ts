import api from '../api';

export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
  phoneNumber?: string;
}

const contactApi = {
  submitContactForm: async (data: ContactFormData) => {
    const response = await api.post('/contact', data);
    return response.data;
  }
};

export default contactApi; 