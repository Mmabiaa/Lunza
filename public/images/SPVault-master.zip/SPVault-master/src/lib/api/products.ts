import api from '../api';

export interface Product {
  _id: string;
  name: string;
  description: string;
  category: string;
  type: string;
  weight: {
    value: number;
    unit: string;
  };
  purity: number;
  price: {
    current: number;
    currency: string;
  };
  stock: number;
  images?: string[];
  reviews?: Review[];
}

export interface Review {
  _id: string;
  user: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export interface CreateProductData {
  name: string;
  description: string;
  category: string;
  type: string;
  weight: {
    value: number;
    unit: string;
  };
  purity: number;
  price: {
    current: number;
    currency: string;
  };
  stock: number;
  images?: string[];
}

const productsApi = {
  getAllProducts: async () => {
    const response = await api.get('/products');
    return response.data;
  },

  getProduct: async (id: string) => {
    const response = await api.get(`/products/${id}`);
    return response.data;
  },

  createProduct: async (data: CreateProductData) => {
    const response = await api.post('/products', data);
    return response.data;
  },

  updateProduct: async (id: string, data: Partial<CreateProductData>) => {
    const response = await api.patch(`/products/${id}`, data);
    return response.data;
  },

  deleteProduct: async (id: string) => {
    const response = await api.delete(`/products/${id}`);
    return response.data;
  },

  addReview: async (productId: string, review: { rating: number; comment: string }) => {
    const response = await api.post(`/products/${productId}/reviews`, review);
    return response.data;
  },

  getProductStats: async () => {
    const response = await api.get('/products/stats');
    return response.data;
  }
};

export default productsApi; 