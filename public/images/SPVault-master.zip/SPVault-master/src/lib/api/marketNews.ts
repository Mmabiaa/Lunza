import api from '../api';

export interface MarketNews {
  _id: string;
  title: string;
  content: string;
  summary: string;
  category: string;
  source: {
    name: string;
    url?: string;
  };
  impact: {
    level: 'low' | 'medium' | 'high';
    description: string;
  };
  relatedAssets: string[];
  createdAt: string;
  updatedAt: string;
}

export interface CreateMarketNewsData {
  title: string;
  content: string;
  summary: string;
  category: string;
  source: {
    name: string;
    url?: string;
  };
  impact: {
    level: 'low' | 'medium' | 'high';
    description: string;
  };
  relatedAssets: string[];
}

const marketNewsApi = {
  getAllNews: async () => {
    const response = await api.get('/market-news');
    return response.data;
  },

  getNews: async (id: string) => {
    const response = await api.get(`/market-news/${id}`);
    return response.data;
  },

  createNews: async (data: CreateMarketNewsData) => {
    const response = await api.post('/market-news', data);
    return response.data;
  },

  updateNews: async (id: string, data: Partial<CreateMarketNewsData>) => {
    const response = await api.patch(`/market-news/${id}`, data);
    return response.data;
  },

  deleteNews: async (id: string) => {
    const response = await api.delete(`/market-news/${id}`);
    return response.data;
  },

  getNewsStats: async () => {
    const response = await api.get('/market-news/stats');
    return response.data;
  }
};

export default marketNewsApi; 