import api from '../api';

export interface Consignment {
  _id: string;
  type: 'purchase' | 'sale' | 'storage';
  items: {
    product: string;
    quantity: number;
    price: number;
  }[];
  shippingAddress: {
    street: string;
    city: string;
    state: string;
    country: string;
    zipCode: string;
  };
  payment: {
    method: string;
    amount: number;
    currency: string;
  };
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  trackingNumber?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateConsignmentData {
  type: 'purchase' | 'sale' | 'storage';
  items: {
    product: string;
    quantity: number;
    price: number;
  }[];
  shippingAddress: {
    street: string;
    city: string;
    state: string;
    country: string;
    zipCode: string;
  };
  payment: {
    method: string;
    amount: number;
    currency: string;
  };
}

const consignmentsApi = {
  getAllConsignments: async () => {
    const response = await api.get('/consignments');
    return response.data;
  },

  getMyConsignments: async () => {
    const response = await api.get('/consignments/my-consignments');
    return response.data;
  },

  getConsignment: async (id: string) => {
    const response = await api.get(`/consignments/${id}`);
    return response.data;
  },

  createConsignment: async (data: CreateConsignmentData) => {
    const response = await api.post('/consignments', data);
    return response.data;
  },

  updateConsignment: async (id: string, data: Partial<CreateConsignmentData>) => {
    const response = await api.patch(`/consignments/${id}`, data);
    return response.data;
  },

  deleteConsignment: async (id: string) => {
    const response = await api.delete(`/consignments/${id}`);
    return response.data;
  },

  trackConsignment: async (trackingNumber: string) => {
    const response = await api.get(`/consignments/track/${trackingNumber}`);
    return response.data;
  }
};

export default consignmentsApi; 