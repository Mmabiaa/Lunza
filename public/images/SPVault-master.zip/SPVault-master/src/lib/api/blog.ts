import api from '../api';

export interface BlogPost {
  _id: string;
  title: string;
  content: string;
  summary: string;
  category: string;
  tags: string[];
  author: {
    _id: string;
    firstName: string;
    lastName: string;
  };
  likes: string[];
  comments: Comment[];
  views: number;
  createdAt: string;
  updatedAt: string;
}

export interface Comment {
  _id: string;
  content: string;
  user: {
    _id: string;
    firstName: string;
    lastName: string;
  };
  createdAt: string;
}

export interface CreateBlogData {
  title: string;
  content: string;
  summary: string;
  category: string;
  tags: string[];
}

const blogApi = {
  getAllPosts: async () => {
    const response = await api.get('/blog');
    return response.data;
  },

  getPost: async (slug: string) => {
    const response = await api.get(`/blog/${slug}`);
    return response.data;
  },

  createPost: async (data: CreateBlogData) => {
    const response = await api.post('/blog', data);
    return response.data;
  },

  updatePost: async (id: string, data: Partial<CreateBlogData>) => {
    const response = await api.patch(`/blog/${id}`, data);
    return response.data;
  },

  deletePost: async (id: string) => {
    const response = await api.delete(`/blog/${id}`);
    return response.data;
  },

  addComment: async (postId: string, content: string) => {
    const response = await api.post(`/blog/${postId}/comments`, { content });
    return response.data;
  },

  likePost: async (postId: string) => {
    const response = await api.patch(`/blog/${postId}/like`);
    return response.data;
  },

  getBlogStats: async () => {
    const response = await api.get('/blog/stats');
    return response.data;
  }
};

export default blogApi; 