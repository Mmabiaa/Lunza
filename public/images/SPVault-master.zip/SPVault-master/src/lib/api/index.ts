import authApi from './auth';
import productsApi from './products';
import consignmentsApi from './consignments';
import blogApi from './blog';
import marketNewsApi from './marketNews';
import contactApi from './contact';

export {
  authApi,
  productsApi,
  consignmentsApi,
  blogApi,
  marketNewsApi,
  contactApi
}; 